interface N
{
	void test1();
}
class O implements N
{
	public void test1()
	{
		System.out.println("balle balle");
	}
	public static void main(String[] args) 
	{
		O o1 = new O();
		o1.test1();
		System.out.println("Hello World!");
	}
}
