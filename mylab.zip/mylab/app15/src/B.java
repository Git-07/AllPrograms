interface B
{
}
