interface I
{
	public abstract void test1();
	public abstract void test2();
	public void test3();
	void test4();
}