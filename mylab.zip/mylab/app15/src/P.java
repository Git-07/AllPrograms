interface P
{
	void test1();
	void test2(int u);
}
class Q implements P
{
	public void test1()
	{
		System.out.println("balle balle");
	}
	public void test2(int u)
	{
		System.out.println("hello world");
	}
	public static void main(String[] args) 
	{
		Q q1 = new Q();
		q1.test1();
		q1.test2(19);
		System.out.println("Hello World!");
	}
}
