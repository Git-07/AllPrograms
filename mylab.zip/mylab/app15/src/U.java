interface U
{
	void test1();
	void test2(int i);
	double test3(boolean b);
}
abstract class V implements U
{
	public void test2(int z)
	{
		System.out.println("oye hoye");
	}
}
abstract class W extends V
{
	public void test1()
	{
		System.out.println("o-teri");
	}
	abstract void test4();
}
class X extends W
{
	public double test3(boolean b)
	{
		System.out.println("aaila");
		return 28.89;
	}
	void test4()
	{
		System.out.println("ui-ma");
	}
	public static void main(String[] args) 
	{
		X x1 = new X();
		x1.test1();
		x1.test2(1);
		x1.test4();
		System.out.println(x1.test3(true));
	}
}
