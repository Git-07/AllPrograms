interface J
{
	void test()
	{
	}
}
