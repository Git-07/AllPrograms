class  Z2
{
	public static void main(String[] args) 
	{
		Z2 z1 = new Z2(12);
		System.out.println("-------");
	}
}
