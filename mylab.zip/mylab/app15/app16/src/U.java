class U 
{
	void test1()
	{
		System.out.println("form test1");
	}
}
interface V
{
	void test2();
}
class W extends U implements V
{
	public  void test2()
	{
		System.out.println("from test2");
	}
	public static void main(String[] args) 
	{
		W w1 = new W();
		w1.test1();
		w1.test2();
		System.out.println("Hello World!");
	}
}
