public abstract class AbstractFactory
{
	abstract Color getColor(String color);
	abstract Shape getShappe(String shape);
}
