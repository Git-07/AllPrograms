public interface Shape1
{
	 void draw();
}
class Rectangle implements Shape1
{
	 public void draw()
	{
		System.out.println("inside rectangle draw method");
	}
}
class Square implements Shape1
{
	public void draw()
	{
	System.out.println("inside square draw method");
	}
}
class Circle implements Shape1
{
	 public void draw()
	{
	System.out.println("inside circle draw method");
	}
}
class ShapeFactory1
{
	Shape1 getShape(String shapeType)
	{
		if(shapeType == null)
		{
			return null;
		}
		if(shapeType.equals("RECTANGLE"))
		{
			return new Rectangle();
		}
		if(shapeType.equals("CIRCLE"))
		{
			return new Circle();
		}
		if(shapeType.equals("SQUARE"))
		{
			return new Square();
		}
		return null;
	}

}
class FactoryPatternDemo
{
	public static void main(String[] args) 
	{
		ShapeFactory1 shapeFactory = new ShapeFactory1();
		Shape1 shape1 = shapeFactory.getShape("RECTANGLE");
		shape1.draw();
		Shape1 shape2 = shapeFactory.getShape("CIRCLE");
		shape2.draw();
		Shape1 shape3 = shapeFactory.getShape("SQUARE");
		shape3.draw();
	}
}
			