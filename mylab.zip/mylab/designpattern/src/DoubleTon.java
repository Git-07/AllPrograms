class DoubleTon 
{
	static int i = 20;
	static int j = 40;
	private static DoubleTon[] tons = new DoubleTon[2];
	private static int index;
	private DoubleTon()
	{
		System.out.println("DoubleTon");
	}
	static
	{
		tons[0] = new DoubleTon();
		tons[1] = new DoubleTon();
	}
	public static DoubleTon getobject()
	{
		return tons[(index++)%2];
	}
}
class T1
{
	public static void main(String[] ar)
	{
		DoubleTon d1 = DoubleTon.getobject();
		DoubleTon d2 = DoubleTon.getobject();
		DoubleTon d3 = DoubleTon.getobject();
		DoubleTon d4 = DoubleTon.getobject();
		System.out.println(d1.i);
		System.out.println(d2.i);
		System.out.println(d3.j);
		System.out.println(d4.j);
	}
}
