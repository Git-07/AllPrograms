class SingleTon
{
	static int i = 20;
	private static SingleTon o = null;
		static
		{
			o = new SingleTon();
		}
		private SingleTon()
		{
			System.out.println("from singleton");
		}
		public static SingleTon geo()
		{
			return o;
		}
}
class R
{
	public static void main(String[] ar)
	{
		//SingleTon o1 = new SingleTon();
		SingleTon o2 = SingleTon.geo();
		SingleTon o3 = SingleTon.geo();
		SingleTon o4 = SingleTon.geo();
		SingleTon o5 = SingleTon.geo();
		System.out.println(o2.i);
		System.out.println(o3.i);
		System.out.println(o4.i);
		System.out.println(o5.i);
	}
}