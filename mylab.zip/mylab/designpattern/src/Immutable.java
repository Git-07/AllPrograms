class  Immutable
{
	private int i;
	private String s1;
	private double d1;
	Immutable(int i,String s1, double d1)
	{
		this.i = i;
		this.s1 = s1;
		this.d1 = d1;
	}
	void print()
	{
		System.out.println(i);
		System.out.println(s1);
		System.out.println(d1);
	}
	int getI()
	{
		return i;
	}
	double getD()
	{
		return d1;
	}
	String getS()
	{
		return s1;
	}
}
class U
{
	public static void main(String[] args) 
	{
		Immutable o1 = new Immutable(1,"mohit",1.2);
		o1.print();
		System.out.println(o1.getI());
		System.out.println(o1.getD());
		System.out.println(o1.getS());
		Immutable o2 = new Immutable(2,"latwal",2.3);
		o2.print();
		System.out.println(o2.getI());
		System.out.println(o2.getD());
		System.out.println(o2.getS());
	}
}
