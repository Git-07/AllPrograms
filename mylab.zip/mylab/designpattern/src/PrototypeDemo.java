
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class ProtoypeDemo
{
	public static void main(String[] args) throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("enter employee id:");
		int eid = Integer.parseInt(br.readLine());
		System.out.print("\n");

		System.out.print("enter employee name:");
		String ename = br.readLine();
		System.out.print("\n");

		System.out.print("enter employee designation:");
		String edesignation = br.readLine();
		System.out.print("\n");	

		System.out.print("enter employee address:");
		String eaddress = br.readLine();
		System.out.print("\n");

		System.out.print("enter employee salary:");
		double esalary = Double.parseDouble(br.readLine());
		System.out.print("\n");
		
		EmployeeRecord e1 = new EmployeeRecord(eid,ename,edesignation,esalary,eaddress);
		e1.showRecord();
		System.out.print("\n");

		EmployeeRecord e2 = (EmployeeRecord) e1.getClone();
		e2.showRecord();
	}
}

