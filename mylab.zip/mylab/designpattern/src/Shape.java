public interface Shape
{
	public void draw();
} 
class Rectangle implements Shape
{
	public void draw()
	{
		System.out.println("inside rectangle");
	}
}
class Square implements Shape
{
	public void draw()
	{
		System.out.println("inside square");
	}
}
class Circle implements Shape
{
	public void draw()
	{
		System.out.println("inside circle");
	}
}
 




