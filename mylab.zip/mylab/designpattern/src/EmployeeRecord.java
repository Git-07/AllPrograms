interface Prototype
{
	public Prototype getClone();
}

class EmployeeRecord implements Prototype
{
	private int id;
	private String name , designation;
	private double salary;
	private String address;
	public EmployeeRecord()
	{
		System.out.println("Employee record of oracle corporation");
		System.out.println("---------------");
		System.out.println("id"+"\t"+"name"+"\t"+"designation"+"\t"+"salary"+"\t"+"address");
	}
	public EmployeeRecord(int id,String name,String designation,double salary,String address)
	{
		this();
		this.id = id;
		this.name = name;
		this.designation = designation;
		this.salary = salary;
		this.address = address;
	}
	public void showRecord()
	{
		System.out.println(id+"\t"+name+"\t"+designation+"\t"+salary+"\t"+address);
	}
	public Prototype getClone()
	{
		return new EmployeeRecord(id,name,designation,salary,address);
	}
}
importjava.io.BufferedReader;
importjava.io.IOException;
importjava.io.InputStreamReader;
class ProtoypeDemo
{
	public static void main(String[] args)throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("enter employee id:");
		int id = Integer.parseInt(br.readLine());
		System.out.print("\n");
		System.out.print("enter employee name:");
		String name = br.readLine();
		System.out.print("\n");
		System.out.print("enter employee designation:");
		String designation = br.readLine();
		System.out.print("\n");	
		System.out.print("enter employee address:");
		String address = br.readLine();
		System.out.print("\n");
		System.out.print("enter employee salary:");
		double salary = Double.parseDouble(br.readLine());
		System.out.print("\n");
		
		EmployeeRecord e1 = new EmployeeRecord(id,name,designation,salary,address);
		e1.showRecord();
		System.out.print("\n");

		EmployeeRecord e2 = (EmployeeRecord)e1.getClone();
		e2.showRecord();
	}
}


