class F 
{
	int i;
	int j;
	F(int k)
	{
		i = 5;
		System.out.println("yo yo");
	}
	public static void main(String[] args) 
	{
		F f1 = new F(2);
		System.out.println(f1.i);
	}
}
