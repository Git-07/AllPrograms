class P 
{
	P()
	{
		this(10,1);
		System.out.println("hi");
	}
	P(int i,int j)
	{
		System.out.println("bye");
	}
	public static void main(String[] args) 
	{
		P p1 = new P();
		System.out.println("Hello World!");
		P p2 = new P();
		System.out.println("bye");
	}
}
