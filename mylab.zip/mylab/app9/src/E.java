class  E
{
	int i;
	E(int k)
	{
		i = k;
		System.out.println("yipee");
	}
	public static void main(String[] args) 
	{
		E e1 = new E(9);
		System.out.println("Hello World!");
		E e2 = new E(90);
		System.out.println("Hello World!");
		E e3 = new E(900);
		System.out.println("Hello World!");
		System.out.println(e1.i);
		System.out.println(e2.i);
		System.out.println(e3.i);

	}

}
