class N
{
	N()
	{
		System.out.println("hello");
	}
	N(int i)
	{
		this();
		System.out.println("hi");
	}
	public static void main(String[] args) 
	{
		N n1 = new N();
		System.out.println("hakina matata");
		N n2 = new N();
		System.out.println("timon and pumba");
	}
}
