class O 
{
	O()
	{
		this(10);
		System.out.println("don");
	}
	O(int i)
	{
		System.out.println("hi");
	}
	public static void main(String[] args) 
	{
		O o1 = new O();
		System.out.println("Hello World!");
		O o2 = new O();
		System.out.println("bye");
	}
}
