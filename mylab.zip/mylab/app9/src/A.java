class A 
{
	A()
	{
		System.out.println("hi");
	}
	public static void main(String[] args) 
	{
		A a1 = new A();
		System.out.println("Hello World!");
	}
}
