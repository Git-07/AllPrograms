class D
{
	int i;
	int j = 10;
	D()
	{
		System.out.println("blah blah");
		i = 1;
		j = 2;
	}
	public static void main(String[] args) 
	{
		D d1 = new D();
		D d2 = new D();
		System.out.println("Hello World!");
		System.out.println(d1.i);
		System.out.println(d2.i);
	}
}
