class B 
{
	B()
	{
		System.out.println("balle balle");
	}
	public static void main(String[] args) 
	{
		B b1 = new B();
		System.out.println("blah blah");
		B b2 = new B();
		System.out.println("Hello World!");
	}
}
