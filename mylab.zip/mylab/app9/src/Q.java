class Q 
{
	Q()
	{
		this(10);
		System.out.println("hi");
	}
	Q(int i)
	{
		this(1,2);
		System.out.println("wassup");
	}
	Q(int i,int j)
	{
		System.out.println("nothing");
	}

	public static void main(String[] args) 
	{
		Q q1 = new Q();
		System.out.println("Hello World!");
		Q q2 = new Q();
		System.out.println("hurrey");
		Q q3 = new Q();
		System.out.println("balle balle");
	}
}
