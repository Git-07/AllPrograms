class J 
{
	J()
	{
		System.out.println("baadsah");
	}
	J(int i)
	{
		System.out.println("ki");
	}
	public static void main(String[] args) 
	{
		J j1 = new J();
		System.out.println("Hello World!");
		J J2 = new J();
		System.out.println("Hello World!");
		J j3 = new J(2);
		System.out.println("Hello World!");
		J j4 = new J(1);
		System.out.println("Hello World!");
	}
}
