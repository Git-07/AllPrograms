class E 

{
	static int i = 100;
	static int j = test();
	static int test()
	{
		System.out.println("test started");
		test1();
		System.out.println("test ended");
		return 10;
	}
	static int test1()
	{
		main(null);
		System.out.println("test1-ended");
		return 20;
	}
	public static void main(String[] args) 
	{
		System.out.println("main started");
		int i = 100;
		System.out.println("main ended");
	}
	static 
	{
		system.out.println("siib-2");
		test();
		System.out.println("")
}
