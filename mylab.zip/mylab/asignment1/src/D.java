class D 
{
	static int i = test();
	static int test()
	{
		System.out.println("test method started");
		main(null);
		System.out.println("test method ended");
		return 10;
	}
	public static void main(String[] args) 
	{
		int i = 10;
		System.out.println("main-1");
		System.out.println(10);
		System.out.println(i);
		System.out.println(test());
	}
	static
	{
		System.out.println("from sib1");
	}
}
