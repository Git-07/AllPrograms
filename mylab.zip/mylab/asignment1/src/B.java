class B 
{
	static
	{
		System.out.println("sib-2");
	}
	static int i = test();
	static int test()
	{
		System.out.println("test begin");
		return 10;
	}
	static 
	{
		System.out.println("sib-1");
	}
	public static void main(String[] args) 
	{
		int i = 104;
		i = i + i++ + i++ + ++i + ++i + i++ + i++;
		System.out.println("main begin");
		System.out.println("main end");
		System.out.println(i);
		System.out.println(B.i);
		return;
	}
	static
	{
		System.out.println("sib-4");
	}
	static
	{
		System.out.println("sib-3");
	}
}
