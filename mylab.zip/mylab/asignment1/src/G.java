class G 
{
	static
	{
		System.out.println("sib started");
		int i = test();
		System.out.println("sib-ended");
	}
	static
	{
		System.out.println("sib1-started");
		int i = test();
		System.out.println("sib1-ended");
	}
	static int test()
	{
		System.out.println("test1-started");
		int i = test2();
		System.out.println("test1-ended");
		return 200;
	}
	static int test2()
	{
		System.out.println("test2-started");
		String[]args = null;
		main(args);
		System.out.println("test2-ended");
		return 100;
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		System.out.println("hillo world");
	}
}
