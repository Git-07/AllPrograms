class F 
{
	public static void main(String[] args) 
	{
		System.out.println("maiin started");
		int i = 100;
		i = 300;
		System.out.println(i);
		System.out.println("main ended");
		test();
		System.out.println("main completely ended");
	}
	static int test()
	{
		System.out.println("test started");
		test1("lara technologies");
		System.out.println("test ended");
		return 10;
	}
	static int test1(String s)
	{
		System.out.println("test2 started");
		System.out.println(s);
		System.out.println("test2 ended");
		return 1;
	}
}



