class C 
{
	static int i = 10;
	static
	{
		System.out.println("1st sib");
	}
	public static void main(String[] args) 
	{
		char i ='t';
		System.out.println("main begin");
		System.out.println(B.i);
		System.out.println(i);
		B.i = 200;
		System.out.println(B.i);
	}
	static
	{
		System.out.println("sib-1");
		main(null);
		System.out.println("siib-2");
	}
}
