class R 
{
	enum En
	{
		c1,c2,c3,c4;
	}
}
class S
{
	public static void main(String[] args) 
	{
		R.En e1 = R.En.c1;
		R.En e2 = R.En.c2;
		R.En e3 = R.En.c3;
		R.En e4 = R.En.c4;
		System.out.println(e1);
		System.out.println(e2);
		System.out.println(e3);
		System.out.println(e4);
	}
}
