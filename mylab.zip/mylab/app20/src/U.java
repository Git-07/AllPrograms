class U 
{
	public static void main(String[] args) 
	{
		Month m1 = Month.August;
		System.out.println(m1);
		m1 = Month.July;
		System.out.println(m1);
		m1 = Month.Feb;
		System.out.println(m1);
		m1 = Month.Jan;
		System.out.println(m1);
	}
}
