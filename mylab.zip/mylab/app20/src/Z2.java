class Z2 
{
	enum D
	{
		con1(11),con2(22),con3(33);
		int i;
		D(int j)
		{
			System.out.println("you are safe");
			this.i = j;
		}
		int test()
		{
			return i;
		}
	}
	public static void main(String[] args) 
	{
		D d1 = D.con3;
		System.out.println(d1);
		System.out.println(d1.i);
		System.out.println(d1.test());
		d1 = D.con2;
		System.out.println(d1);
		System.out.println(d1.i);
		System.out.println(d1.test());
	}
}
