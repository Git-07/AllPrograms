enum V 
{
	c1,c2,c3;
	V()
	{
		System.out.println("from V()");
	}
}
class W
{
	public static void main(String[] args) 
	{
		V v1 = V.c1;//reference v1 is a type of V
		System.out.println(v1);
		V v2 = V.c2;//reference v2 is a type of V
		System.out.println(v2);
		V v3  = V.c1;
		System.out.println(v3);
	}
}
