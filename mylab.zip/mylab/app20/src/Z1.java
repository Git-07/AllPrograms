class Z1 
{
	enum C
	{
		t1,t2,t3,t4,t5;
		void test()
		{
			System.out.println("from test");
		}
	}
	public static void main(String[] args) 
	{
	    C c1 = C.t2; 
		c1.test();
		System.out.println("Hello World!");
		c1 = C.t1;
		c1.test();
		System.out.println("Hello World!");
		c1 = C.t3;
		c1.test();
		System.out.println("Hello World!");
		c1 = C.t5;
		c1.test();
		System.out.println("Hello World!");
	}
}
