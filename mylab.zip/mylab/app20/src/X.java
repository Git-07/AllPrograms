class X 
{
	enum A
	{
		con(100),test(20);
	A(int i)
	{
		System.out.println("from A:"+i);
	}
}

	public static void main(String[] args) 
	{
		A a1 = A.test;
		System.out.println(a1);
		a1 = A.con;
		System.out.println(a1);
	}
}
