class Y 
{
	enum A
	{
		con1,con2(1),con3,con4("abc");
		A()
		{
			System.out.println("A()");
		}
		A(int i)
		{
			System.out.println("A(int i):"+i);
		}
		A(String j)
		{
			System.out.println("A(String):"+j);
		}
	}
	public static void main(String[] args) 
	{
		A a1 = A.con1;
		System.out.println("------");
		System.out.println(a1);
		a1 = A.con2;
		System.out.println(a1);
		a1 = A.con3;
		System.out.println(a1);
		a1 = A.con4;
		System.out.println(a1);
	}
}
