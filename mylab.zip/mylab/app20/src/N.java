class N 
{
	enum En
	{
		Con1,Con2,Con3,Con4;
	}
	public static void main(String[] args) 
	{
		int i;
		En all[] = En.values();
		for(i=0;i<all.length;i++)
		{
			System.out.println(all[i]);
     	}
	}
}
