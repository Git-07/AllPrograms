class M 
{
	enum En 
	{
		 c1,c2,c3,c4;
	}
	public static void main(String[] args) 
	{
		En e1 = En.c4;
		System.out.println(e1);
		En e2 = En.c2;
		System.out.println(e2);
		En e3 = En.c1;
		System.out.println(e3);
		En e4 = En.c3;
		System.out.println(e4);
		
	}
}
