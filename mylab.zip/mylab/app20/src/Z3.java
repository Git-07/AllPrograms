class Z3 
{
	enum E
	{
		t1,t2,t3,t4;
		void method1()
		{
			System.out.println("you are in method 1");
		}
	}
	public static void main(String[] args) 
	{
		E e1 = E.t1;
		System.out.println(e1);
		e1.method1();
		e1 = E.t2;
		System.out.println(e1);
		e1.method1();
		e1 = E.t3;
		System.out.println(e1);
		e1.method1();
	}
}
