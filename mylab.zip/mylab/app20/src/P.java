enum P 
{
    con1,con2,con3;
}
class Q
{
	public static void main(String[] args) 
	{
		P p1 =  P.valueOf("con1");
		System.out.println(p1);
		P p2 =  P.valueOf("con2");
		System.out.println(p2);
		P p3 =  P.valueOf("con4");
		System.out.println(p3);
	}
}
