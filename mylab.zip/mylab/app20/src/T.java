enum Day  
{
	mon,tue,wed,thu,fri,sat,sun;
}
class T
{
	public static void main(String[] args) 
	{
		Day d1 = Day.sat;
		System.out.println(d1);
		d1 = Day.sun;
		System.out.println(d1);
		d1 = Day.mon;
		System.out.println(d1);
		d1 = Day.tue;
		System.out.println(d1);
	}
}
