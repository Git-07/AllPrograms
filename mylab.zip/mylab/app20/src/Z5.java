class Z5 
{
	enum X
	{
		A,B,C,D
	}
	public static void main(String[] args) 
	{
		X x1 = X.C;
		switch(x1)
		{
			case A:
			{
		   System.out.println("from A");
		   break;
			}
			case B:
			{
				System.out.println("from B");
				break;
			}
			case C:
			{
				System.out.println("from C");
				break;
			}
			case D:
			{
				System.out.println("from D");
				break;
			}
		}


	}
}
