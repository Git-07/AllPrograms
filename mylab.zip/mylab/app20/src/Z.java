class Z
{
	enum B
	{
		con1(1),con2(2),con3(3);
		int i;
		B(int j)
		{
			this.i = j;
		}
	}
	public static void main(String[] args) 
	{
		B b1 = B.con1;
		System.out.println(b1);
		System.out.println(b1.i);
		b1 = B.con2;
		System.out.println(b1);
		System.out.println(b1.i);
		b1 = B.con3;
		System.out.println(b1);
		System.out.println(b1.i);
	}
}
