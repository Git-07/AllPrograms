class L 
{
	static 
	{
		System.out.println("sib-L");
	}
	public static void main(String[] args) 
	{
		System.out.println("L--main begin");
	}
	
}
