class E 
{

	static int i = 1;
	static
	{
		i = 2;
	}
	public static void main(String[] args) 
	{
		System.out.println(i);
	}
}
