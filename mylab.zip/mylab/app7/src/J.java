class J 
{
	static int i = test();
	static
	{
		System.out.println("sib begin");
		main(null);
		System.out.println("sib end");
	}
	static int test()
	{
		System.out.println("test begin");
		main(null);
		System.out.println("test end");
		return 20;
	}
	public static void main(String[] args) 
	{
		System.out.println("main:"+i);
		System.out.println(test1());
	}
	static int test1()
	{
		System.out.println("hello");
		return i++;
	}
}
