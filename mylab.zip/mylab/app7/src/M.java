class M 
{
	static
	{
		System.out.println("sib-m");
	}
	public static void main(String[] args) 
	{
		System.out.println("m-main begin");
		L.main(args);
		System.out.println("m-main end");
	}
}
