class C
{
	static
	{
		System.out.println("sib1");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
	static
	{
		System.out.println("sib2");
	}
}
