class N 
{
	static int i = 10;
	static
	{
		System.out.println("n-sib");
	}
}
class O
{
	static
	{
		System.out.println("o-sib");
	}
	public static void main(String[]ar)
	{
		System.out.println("o-main begin");
		System.out.println(N.i);
		System.out.println("o-main end");
		System.out.println(F.i);
		System.out.println(N.i);
	}
}
