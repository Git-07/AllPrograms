class H 
{
	static int test(short s)
	{
		return s;
	}
	public static void main(String[] args) 
	{
		byte b = 1;
		double d = test(b);//test((double)s);
		System.out.println(d);
	}
}
