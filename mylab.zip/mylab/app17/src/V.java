class V 
{
	public static void main(String[] args) 
	{
		double d = 10.99;
		long l = (long)d;
		float f = (float)d;
		System.out.println(d);
		System.out.println(l);
		System.out.println(f);
	}
}
