class A 
{
	public static void main(String[] args) 
	{
		int i = 10;
		double d =i;
		System.out.println("Hello World!");
	}
}
