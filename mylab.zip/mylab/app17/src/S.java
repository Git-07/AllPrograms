class S 
{
	static int test(double d1)
	{
		return((int)d1);
	}
	public static void main(String[] args) 
	{
		long l = test(1.20);
		System.out.println(l);
		System.out.println(test(1.20));
	}
}
