class C 
{
	public static void main(String[] args) 
	{
		short i = 1;
		double d = i;
		System.out.println("Hello World!");
		System.out.println(d);
	}
}
