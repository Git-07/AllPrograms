class W 
{
	public static void main(String[] args) 
	{
		double d = 10.10;
		int i = (int)d;
		float f = (float)i;
		long l = i;
		System.out.println(i);
		System.out.println(f);
		System.out.println(l);
	}
}
