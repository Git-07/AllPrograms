class P 
{
	public static void main(String[] args) 
	{
		double d1 = 10.9;
		int i = (int)d1;
		System.out.println(i);
	}
}
