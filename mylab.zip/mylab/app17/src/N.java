class N 
{

	static int test1(double d)
	{
		System.out.println("from earth");
		return (int)d;
	}
	public static void main(String[] args) 
	{
		int i = 10;
		byte b = 2;
		test1(i);
		test1(b);
	}
}
