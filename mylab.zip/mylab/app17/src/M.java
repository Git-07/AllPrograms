class M 
{
	public static void main(String[] args) 
	{
		byte b = 10;
		int i = b;
		int j = b;
		double d1 = i;
		double d2 = j;
		System.out.println(d1);
		System.out.println(d2);
	}
}
