class D 
{
	public static void main(String[] args) 
	{
		int i = 20;
		double f = i;
		System.out.println(f);
		System.out.println("hello world");
	}
}
