class F 
{
	static void test(int i)
	{
		System.out.println("hello to all");
	}
	public static void main(String[] args) 
	{
		double d = 10;
		test((int)d);
		System.out.println("Hello World!");
	}
}
