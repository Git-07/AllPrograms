class U 
{
	public static void main(String[] args) 
	{
		int i = 10;
		short s = (short)i;
		int j = s;
		System.out.println(i);
		System.out.println(j);
		System.out.println(s);
	}
}
