class T 
{
	public static void main(String[] args) 
	{
		double d1 = 110.2;
		float f1 = (float)d1;
		int i =(int)f1;
		short s =(short)i;
		byte b = (byte)s;
		System.out.println(d1);
		System.out.println(f1);
		System.out.println(i);
		System.out.println(s);
		System.out.println(b);
	}
}
