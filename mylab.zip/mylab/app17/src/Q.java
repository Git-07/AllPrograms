class Q 
{
	public static void main(String[] args) 
	{
		double d1 = 12.9;
		int i = d1;
		System.out.println("Hello World!");
	}
}
