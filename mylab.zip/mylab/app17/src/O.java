class O 
{
	static int test1()
	{
		byte b = 10;
		return b;
	}
	static int test2()
	{
		short a = 1;
		return a;
	}
	public static void main(String[] args) 
	{
		double d1 = test1();
		double d2 = test2();
		System.out.println("Hello World!");
	}
}
