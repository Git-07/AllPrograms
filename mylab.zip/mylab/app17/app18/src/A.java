class A
{
}
class B extends A
{
}
class C extends B
{
}
class D extends C
{
}
class Manager1
{
	public static void main(String[] args) 
	{
		Object obj = new Object();
		A a1 = new A();
		B b1 = new B();
		C c1 = new C();
		D d1 = new D();
		System.out.println("Hello World!");
	}
}
class Manager2
{
	public static void main(String[] arg)
	{
		Object obj = null;
		A a1 = null;
		B b1 = null;
		C c1 = null;
		D d1 = null;
		obj = new Object();
		a1 = new A();
		b1 = new B();
		c1 = new C();
		d1 = new D();
		System.out.println("done");
	}
}
class Manager4
{
	static void test1(A a1)
	{
		System.out.println("test1(A)");
	}
	static void test2(C c1)
	{
		System.out.println("test2(C)");
	}
	static D test3()
	{
		D d1 = new D();
		return d1;
	}
	static B test4()
	{
		return new B();
	}
	public static void main(String[] ar)
	{
	test1(new A());
	C c1 = new C();
	test2(c1);
	D d1 = test3();
	B b1 = test4();
	System.out.println("done");
	}
}
class Manager5
{
	public static void main(String[]ar)
	{
		A a1 = new B();//A a1 = (A)new B(),here object is creatint to B() but it is being auto upcasted by compiler;
		B b1 = new C();
		C c1 = new D();
		Object o1 = new A();//auto upcasting;
		System.out.println("done");
	}
}
class Manager6
{
	public static void main(String[] ar)
	{
		A a1 = new C();//autoupcassting;
		Object o1 = new D();//auto upcasting;
		B b1 = new C();
		C c1 = new C();
		B b2 = new D();
		Object o2 = new C();
		System.out.println("done");
	}
}
class Manager7
{
	public static void main(String [] ar)
	{
		A a1 = null;
		B b1 = null;
		C c1 = null;
		D d1 = null;
		a1 = b1;
		b1 = c1;
		c1 = d1;
		System.out.println("done");
	}
}
class Manager8
{
	static void test(A a1)
	{
		System.out.println("from test");
	}
	public static void main(String[]ar)
	{
		test(new B());
		test(new C());
		test(new D());
		B b1 = new B();
		test(b1);//autoucasted to A;
		D d1 = new D();
		test(d1);
	}
}
class Manager9
{
	static Object test1()
	{
		D d1 = new D();
		return d1;
	}
	public static void main(String[]ar)
	{
		Object obj = test1();//auto upcasting;
		System.out.println("done");
	}
}
class Manager10
{
	static C test()
	{
		D d1 = new D();
		return d1;
	}
	public static void main(String []ar)
	{
		A a1 = test();
		System.out.println("done");
	}
}
class Manager11
{
	static A test1(C c1)
	{
		return test2(c1);//autoupcasting
	}
	static B test2(C c1)
	{
		return c1;
	}
	public static void main(String []ar)
	{
		D d1 = new D();
		Object o1 = test1(d1);
		System.out.println("done");
	}
}
class Manager12
{
	public static void main(String[]ar)
	{
		A a1 = new D();
		B b1 = (B) a1;
		C c1 = (C) b1;
		D d1 = (D) c1;
		System.out.println("done");
	}
}
class Manager13
{
	public static void main(String[] ar)
	{
		A a1 = new B();
		System.out.println("done");
	}
}
class Manager14
{
	public static void main(String[] ar)
	{
		A a1 = new B();
		B b1 = (B) a1;//explicit downcasting
		System.out.println("done");
	}
}
class Manager15
{
	public static void main(String[] ar)
	{
		B b1 = new D();
	   //downcasting is not possible
		System.out.println("done");
	}
}
class Manager16
{
	public static void main(String[] ar)
	{
		B b1 = new D();
		C c1 = (C) b1;
		System.out.println("done");
	}
}
class Manager17
{
	public static void main(String[] ar)
	{
		A a1 = new D();
		B b1 = (B) a1;
		C c1 = (C) b1;
		D d1 = (D) a1;
		System.out.println("done");
	}
}
class Manager18
{
	static void test(B b1)
	{
		System.out.println("hello");
	}
	public static void main(String[] ar)
	{
		A a1 = new B();
		test((B)a1);
		System.out.println("done");
	}
}
class Manager19
{
	static void test(B b1)
	{
		System.out.println("hello");
	}
	public static void main(String[] ar)
	{
		A a1 = new B();
		test((B)a1);
		System.out.println("done");
	}
}
class Manager20
{
	static C test()
	{
		A a1 = new D();
		return (C)a1;
	}
	public static void main(String[] ar)
	{
		D d1 = (D)test();
		System.out.println("done");
	}
}
class Manager21
{
	static C test()
	{
		A a1 = new D();
		return (C)a1;
	}
	public static void main(String[] ar)
	{
		D d1 = (D) test();
	}
}
class Manager22
{
	public static void main(String[] ar)
	{
		A a1 = new A();
		B b1 = (B)a1;
		A a2 = new A();
		B b2 = (B)a2;
	}
}
class Manager23
{
	public static void main(String[] ar)
	{
		A a1 = new C();
		System.out.println("jingle bells");
		B b1 = (B)a1;
		System.out.println("jingle bells");
		C c1 = (C)a1;
		System.out.println("jingle all the way");
	}
}
class Manager24
{
	public static void main(String[] ar)
	{
		A a1 = new B();
		System.out.println("hello");
		B b1 = (B) a1;
		System.out.println("to all");
		C c1 = (C) a1;
		System.out.println("-----");
	}
}
class Manager25
{
	public static void main(String[] ar)
	{
		 A a1 = new C();
		 System.out.println("hello");
		 B b1 = (B) a1;
		 System.out.println("to all");
		 C c1 = (C) a1;
		 System.out.println("------");
		 D d1 = (D) a1;
		 System.out.println("folks");
	}
}
class Manager26
{
	public static void main(String[] ar)
	{
		A a1 = new B();//auto upcasting
		B b1 = (B)a1;//down casting
		System.out.println("hello");
		A a2 = new A();
		B b2 = (B)a2;
	}
}
class Manager27
{
	public static void main(String[] ar)
	{
		A a1 = new B();
		System.out.println(a1 instanceof A);
		System.out.println(a1 instanceof B);
		System.out.println(a1 instanceof C);
		System.out.println(a1 instanceof D);
	}
}
class Manager28
{
	public static void main(String[] arg)
	{
		A a1 = new D();
		System.out.println(a1 instanceof Object);
		System.out.println(a1 instanceof A);
		System.out.println(a1 instanceof B);
		System.out.println(a1 instanceof C);
		System.out.println(a1 instanceof D);
	}
}
class Manager29
{
	public static void main(String[] ar)
	{
		A a1 = new D();
		System.out.println(a1 instanceof A);
		System.out.println(a1 instanceof B);
		System.out.println(a1 instanceof C);
		System.out.println(a1 instanceof D);
		
	}
}
class Manager30
{
	public static void main(String[] ar)
	{
		A a1 = new C();	
		 if(a1 instanceof A)
		{
			System.out.println("hello");
			A a2 = (A) a1;
		}
		if(a1 instanceof B)
		{
			System.out.println("hello");
			B b2 = (B) a1;
		}
		if(a1 instanceof C)
		{
		    System.out.println("hello");
			C c2 = (C)a1;
		}
		if(a1 instanceof D)
		{
				System.out.println("hello");
				D d2 = (D) a1;
		}
	}
}
class Manager31
{
	static void test(Object obj)
	{
		if(obj instanceof A)
		{
			System.out.println("hello");
		}
		if(obj instanceof B)
		{
			System.out.println("hello");
		}
		if(obj instanceof C)
		{
			System.out.println("hello");
		}
		if(obj instanceof D)
		{
			System.out.println("hello");
		}
		System.out.println("------");
	}
	public static void main(String[] ar)
	{
		A a1 = new A();
		A a2 = new B();
		A a3 = new C();
		A a4 = new D();
		test(a1);
		test(a2);
		test(a3);
		test(a4);
	}
}



