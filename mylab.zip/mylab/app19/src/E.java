class E 
{
	int i = 1;
	void test()
	{
		System.out.println(i);//this.i
	}
	public static void main(String[] args) 
	{
		E e = new E();
		System.out.println("Hello World!");
		e.test();	
			
	}

}
