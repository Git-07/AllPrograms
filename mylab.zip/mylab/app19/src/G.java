class G 
{
	static int i;
	{
		i = 20;//this.i = 20
	}
	static
	{
		i = 30;
	}
	public static void main(String[] args) 
	{
		System.out.println(i);
	}
}