class L 
{
	int i;
	void test1()
	{
		System.out.println("from test1:" + i);
		i = 10;
		test2();
	}
	void test2()
	{
		System.out.println("from test2:" + i);
		i = 20;
	}
	public static void main(String[] args) 
	{
		L l = new L();
		System.out.println("main1:" + l.i);
		l.test1();
		System.out.println("main2:" + l.i);
		l.i = 30;
		l.test2();
		System.out.println("main3:" + l.i);

	}
}
