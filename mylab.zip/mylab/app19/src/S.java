class S 
{
	private int i;
	S(int i)
	{
		this.i = i;;
	}
	int get()
	{
		return i;//this.i
	}
}
class T
{
	public static void main(String[] args) 
	{
		S s1 = new S(2);
		System.out.println(s1.get());
		System.out.println(s1.get());
		System.out.println(s1.get());
		S s2 = new S(3);
		System.out.println(s2.get());
		System.out.println(s2.get());
		System.out.println(s2.get());
		System.out.println(s2.get());
	}
}
