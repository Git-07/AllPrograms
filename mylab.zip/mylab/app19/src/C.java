class C 
{
	int i;
	void main(String[] args) 
	{
		C c = new C();
		System.out.println(C.i);
	}
}
