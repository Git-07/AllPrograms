class B 
{
	int i;
}
class Manager3
{
	static B test(B b1)
	{
		B b2 = new B();
		b2.i = b1.i + b2.i;
		return b2;
	}
	public static void main(String[] args) 
	{
		B obj = new B();
		obj.i = 20;
		B obj1 = test(obj);
		System.out.println(obj.i);
		System.out.println(obj1.i);
	}
}
