class A1 
{
	int i;
}
class Manager2
{
	static void test(A1 a1)
	{
		A1 a2 = new A1();
		a2.i = a1.i;
		System.out.println(a2.i);
	}
	static void test()
	{
		A1 a3 = new A1();
		a3.i = 40;
		System.out.println(a3.i);
	}
		public static void main(String[] args) 
	{
		A1 obj = new A1();
		obj.i = 20;
		test(obj);
		test();
	}
}
