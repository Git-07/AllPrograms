class B1 
{
	int i;
}
class Manager5
{
	static int test(B1 b1,B1 b2)
	{
		B1 b3 = new B1();
		b3.i = b1.i + b2.i;
		System.out.println(b3.i);
		return b3.i;
	}
	public static void main(String[] args) 
	{
		B1 obj = new B1();
		B1 obj1 = new B1();
		obj.i = 20;
		obj1.i = 30;
		int d = test(obj,obj1);
		System.out.println(obj.i);
		System.out.println(obj1.i);
		System.out.println(d);
	}
}
		