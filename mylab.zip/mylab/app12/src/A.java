class A 
{
	static 
	{
		System.out.println("A SIB");
	}
}
class B extends A
{
	static 
	{
		System.out.println("B SIB");
	}
}
class C extends B
{
    static 
	{
		System.out.println("C SIB");
	}
}
class D
{
	public static void main(String[] args) 
	{
		B b1 = new B();
		System.out.println("Hello World!");
	}
}
class E
{
	public static void main(String[]ar)
	{
		C c1 = new C();
		System.out.println("done");
	}
}
class F
{
	public static void main(String[]ar)
	{
		A a1 = new A();
		System.out.println("hey");
	}
}