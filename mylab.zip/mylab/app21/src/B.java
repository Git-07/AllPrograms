class B 
{
	class C
	{
	}
	static class D
	{
	}
	void test1()
	{
		C c1 = new C();
		D d1 = new D();
		test2();
	}
	static void test2()
	{
		System.out.println("hello hello you are a buffallo");
	}
	public static void main(String[] args) 
	{
		test2();
		System.out.println("Hello World!");
	}
}
