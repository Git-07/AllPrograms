class F 
{
	int i;
	static int j;
	void test1()
	{
		i = 1;
		j = 2;
		test1();
		test2();
	}
	static void test2()
	{
		j = 2;
		test2();
		H h1 = new H();
	}
	class G
	{
		int m;
		//static int n;(for this inner class should be static)
		void test3()
		{
			i = 110;
			j = 20;
			test1();
			test2();
	}
	}
	//static void test4()
	static class H
	{
		int p;
		static int q;
		void test5()
		{
			j = 20;
			test2();
			q = 10;
			H h1 = new H();
		}
	static void test6()
		{
		j = 20;
		test2();
		q = 10;
		H h1 = new H();
		}
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
