class A 
{
	class B//nonstatic 
	{
	}
	class C//nonstatic
	{
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
