class E 
{
	static class F
	{
		int i;
		static int j;
		void test1()
		{
			j = 5;
			i = 1;
		}
		static void test2()
		{
		}
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
