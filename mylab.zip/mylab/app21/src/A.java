class A 
{
	int i;
	static int j;
	void test1()
	{
		i = 20;
		j = 30;
		test2();
	}
	static void test2()
	{
		j = 30;	
		test2();
	}
	
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
