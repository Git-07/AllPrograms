class G 
{
	class H
	{
	}
	static class I
	{
	}
	public static void main(String[] args) 
	{
		H h1 = null;
		I i1 = new I();
		h1 = new G().new H();
		G g1 = new G();
		h1 = g1.new H();
	    i1 = new G.I();
		System.out.println("Hello World!");
	}
}
