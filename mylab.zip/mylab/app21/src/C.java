class C
{
	int i;
	static int j;
	class D
	{
		public static void main(String[] ar)
		{
	    System.out.println("yellow yellow dirty fellow");
		}
	}
	static class E
	{
	}
	void test1()
	{
		i = 1;
		j = 2;
		//not poossible to create an object to D class
		
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
