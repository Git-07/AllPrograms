class O 
{
	public static void main(String[] args) 
	{
		int i = 10;
		final int j = 20;
		class A
		{
			int k = 2;
			void test()     //declaring a non final local variable to method and using it inside a local 
                          //inner class to the same method .So it is not allowed.  
	     	{
				System.out.println(j);
				System.out.println(k);
			}
		}
		class B
		{
			int l = 20;
			void test()
			{
			  System.out.println(l);
			}
		}
		System.out.println("Hello World!");
		A a1 = new A();
		a1.test();
		B b1 = new B();
		b1.test();
	}
}
