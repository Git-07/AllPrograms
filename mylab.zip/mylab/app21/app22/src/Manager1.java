class Manager1 
{
	public static void main(String[] args) 
	{
		A a1 = new A();
		a1.test1();
		a1.test2();
		System.out.println("Hello World!");
	}
}
