class Manager 
{
	interface A
	{
		void test1();
	}
}
public class Z1 implements Manager.A
{
	public void test1()
	{
		System.out.println("from test1");
	}
	public static void main(String[] args) 
	{
		Z1 z = new Z1();
		z.test1();
		System.out.println("Hello World!");
	}
}
