class Manager4 
{
	public static void main(String[] args) 
	{
		A a1 = new A()  //a1 is pointing to an object to sub class to A
		{
		};

		System.out.println("Hello World!");
		a1.test1();
		a1.test2();
		A a2 = new A()
		{
			void test1()
			{
				System.out.println("AIC-test1");
			}
		};
		a2.test1();
		a2.test2();

	}
}
