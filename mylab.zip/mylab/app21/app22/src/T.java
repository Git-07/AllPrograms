interface U
{
    abstract class A
	{
		abstract void test1();
		void test2()
		{
			System.out.println("test2");
		}
	}
}
class V extends U.A
{
	void test1()
	{
		System.out.println("test1");
	}
}
public class T
{
	public static void main(String[] args) 
	{
		U.A a1 = new V();//
		V v1 = new V();
		a1.test1();
		a1.test2();
		v1.test1();
		v1.test2();
		System.out.println("Hello World!");
	}
}
