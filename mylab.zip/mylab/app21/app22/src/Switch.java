interface Switch
{
	void on();
	void off();
}
class Fan
{
	private boolean runningStatus;
	private int rpmStatus;
	int rpm;
	public Switch getSwitch()
	{
		return new Switch()
		{
			public void on()
			{
				runningStatus = true;
				rpmStatus = 1200;
			}
			public void off()
			{
				runningStatus = false;
				rpmStatus = 0;
			}
		};
	}
	public int getRpmStatus()
	{
		return rpmStatus;
	}
	public boolean getRunningStatus()
	{
		return runningStatus;
	}
}
class Manager14
{
	public static void main(String[]arg)
	{
		Fan f1 = new Fan();
		Switch s1 = f1.getSwitch();
		s1.on();
		System.out.println(f1.getRunningStatus());
		System.out.println(f1.getRpmStatus());
		s1.off();
		System.out.println(f1.getRunningStatus());
		System.out.println(f1.getRpmStatus());
	}
}