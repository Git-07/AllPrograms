interface C
{
	void test1();
	void test2();
} 
