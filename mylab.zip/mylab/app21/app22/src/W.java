interface X
{
	interface A
	{
		void test1();
	}
}
interface Y extends X.A
{
	void test2();
}
public class W implements Y
{
	public void test1()
	{
		System.out.println("from-test1");
	}
	public void test2()
	{
		System.out.println("from-test2");
	}
	public static void main(String[] args) 
	{
		W obj = new W();
		obj.test1();
		obj.test2();
		System.out.println("Hello World!");
	}
}
