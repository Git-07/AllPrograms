interface S
{
	class A  //static by default 
	{
		int i;
		static int j;
	}
}
public class R
{
	public static void main(String[] args) 
	{
		S.A a1 = new S.A();
		System.out.println(new S.A().i);
		System.out.println(S.A.j);
		System.out.println("Hello World!");
	}
}
