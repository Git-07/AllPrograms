class A 
{
	void test1()
	{
		System.out.println("A-test1");
	}
	void test2()
	{
		System.out.println("A-test2");
	}
}
