interface IFace
{
	interface A
	{
		void test1();
		void test2();
	}
}
public class Z implements IFace.A
{
	public void test1()
	{
		System.out.println("fromtest1");
	}
	public void test2()
	{
		System.out.println("fromtest2");
	}
	public static void main(String[] args) 
	{
		Z z1 = new Z();
		z1.test1();
		z1.test2();
		System.out.println("Hello World!");
	}
}
