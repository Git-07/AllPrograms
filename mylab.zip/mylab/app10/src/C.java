class C 
{
	int i;
	void test1()
	{
		System.out.println("hello");
	}
}
class D extends C
{
	int j;

	void test2()
	{
		System.out.println("blah blah");
	}
	public static void main(String[] args) 
	{
		D d1 = new D();
		d1.test1();
		d1.test2();
		System.out.println("------");
		    d1.i = 1;
			d1.j = 2;
			System.out.println(d1.i+","+d1.j);
	}
}
