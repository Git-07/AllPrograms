class S 
{
	S()
	{
		System.out.println("yup");
	}
}
class R extends S
{
	R()
	{
		System.out.println("howde");
	}
}
class T extends R
{
	T()
	{
		System.out.println("hurray");
	}
}
class U
{
	public static void main(String[] args) 
	{
		T t1 = new T();
		System.out.println("Hello World!");
		R r1 = new R();
		System.out.println("hey");
		S s1 = new S();
		System.out.println("ye");
	}
}
