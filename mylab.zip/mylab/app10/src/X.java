class X 
{
}
class Y extends X
{
	Y(int i)
	{         
		System.out.println("hello");
	}
	public static void main(String[] args) 
	{
		Y y1 = new Y(1);
		System.out.println("Hello World!");
	}
}
