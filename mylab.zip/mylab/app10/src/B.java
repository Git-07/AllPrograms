class A 
{
	A(int i)
	{
		System.out.println("blah blah");
	}
}
class B extends A
{
	B()
	{
		System.out.println("huray");
	}
		public static void main(String[] args) 
	{
			A a1 = new A();
			System.out.println("Hello World!");
			B b1 = new B();
	}
}
