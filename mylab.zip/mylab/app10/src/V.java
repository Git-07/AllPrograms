class V
{
	V(int i)
	{
		System.out.println("V()");
	}
}
class W extends V
{
	W(int j)
	{   
		System.out.println("W(int)");
	}
	public static void main(String[] args) 
	{
		V v1 = new V(90);
		System.out.println("Hello World!");
		W w1 = new W(1);
		System.out.println("bye world!");
	}
}
