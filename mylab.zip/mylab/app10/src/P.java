class P 
{
	P()
	{
		System.out.println("aisa hai kya");
	}
}
class Q extends P
{
	Q()
	{
		System.out.println("Q()");
	}
}
class R
{
	public static void main(String[] args) 
	{
		Q q1 = new Q();
		System.out.println("Hello World!");
		P p1 = new P();
		System.out.println("blah blah");
	}
}
