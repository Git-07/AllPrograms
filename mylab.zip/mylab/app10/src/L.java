class L 
{
	L()
	{
		System.out.println("blah blah");
	}
}
class M extends L
{
	
	M()
	{
		System.out.println("don");
	}
}
class N extends M
{
	N()
	{
		System.out.println("ha ha");
	}
}
class O
{
	public static void main(String[] args) 
	{
		L obj1 = new L();
		System.out.println("------");
		M obj2 = new M();
		System.out.println("hurray");
		N obj3 = new N();
		System.out.println("nahi yaar");
	}
}
