class M 
{
	public static void main(String[] args) 
	{
	
		int i = 0; 
		System.out.println(++i);
	}
}
