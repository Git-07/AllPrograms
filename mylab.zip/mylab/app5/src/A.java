class A 
{
	static void test(int i)
	{
		System.out.println("from tets");
		System.out.println(i);
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		test();
		System.out.println("akgfda");
	}
}
