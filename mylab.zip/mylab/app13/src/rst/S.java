package rst;
import lara.N;
class S 
{
	public static void main(String[] args) 
	{
		N n1 = new N();
		System.out.println("Hello World!");
	}
}
