package rst;
import lara.*;
class T 
{
	public static void main(String[] args) 
	{
		N n1 = new N();
		System.out.println("Hello World!");
	}
}
