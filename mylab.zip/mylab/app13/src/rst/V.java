package rst;
import lara.N;
class V extends N 
{
	public static void main(String[] args) 
	{
		 N n1 = new N();
		 N n2 = new N();
		 N n3 = new N();
		System.out.println("Hello World!");
	}
}
