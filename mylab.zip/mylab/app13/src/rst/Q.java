package rst;
class Q 
{
	public static void main(String[] args) 
	{
		N n1 = new N();
		System.out.println("Hello World!");
	}
}
