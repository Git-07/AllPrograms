package rst;
class O 
{
	public static void main(String[] args) 
	{
		lara.N n1 = new lara.N();
		System.out.println(n1.i);
	}
}
