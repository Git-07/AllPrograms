package rst;
class M 
{
	public static void main(String[] args) 
	{
		lara.F f1 = new lara.F();
		System.out.println("Hello World!");
	}
}
