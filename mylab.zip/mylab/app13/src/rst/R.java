package rst;
class R 
{
	public static void main(String[] args) 
	{
		lara.N n1 = new lara.N();
		System.out.println("Hello World!");
	}
}
