package lara;
class H extends F 
{
	public static void main(String[] args) 
	{
		H h1 = new H();
		h1.test1();
		System.out.println("Hello World!");
	}
}
