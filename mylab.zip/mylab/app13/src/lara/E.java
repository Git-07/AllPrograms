package lara;
class E
{
	public static void main(String[] args) 
	{
		A a1 = new A();
		System.out.println(a1.i);
		C c1 = new C();
		System.out.println(c1.i);
		D d1 = new D();
		System.out.println(d1.i);
	}
}
