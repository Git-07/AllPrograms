package lara;
class A
{
	int i;
}

