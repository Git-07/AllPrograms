package lara;
class C extends B 
{
	public static void main(String[] args) 
	{
		C c1 = new C();
		System.out.println(c1.i);
	}
}
