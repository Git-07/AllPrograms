interface H
{
	void test1();
	void test2();
}
class I
{
	public void test1()
	{
		System.out.println("from test1");
	}
}
class J extends I implements H
{
	public void test2()
	{
		System.out.println("from test2");
	}
	public static void main(String[] args) 
	{
		J j = new J();
		j.test1();
		j.test2();
		System.out.println("Hello World!");
	}
}
