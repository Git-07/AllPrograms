class U 
{
	void test()
	{
		System.out.println("from U");
	}
}
class V extends U
{
	void test()
	{
		System.out.println("from V");
	}
	public static void main(String[] args) 
	{
		U u = new U();
		V v = new V();
		u.test();
		v.test();
		System.out.println("Hello World!");
	}
}
