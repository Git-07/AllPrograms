interface E
{
	void test1(int i,int j);
}
abstract class F implements E
{
	void test1()
	{
		System.out.println("from test1");
	}
	abstract void test2();
	public static void main(String[]args) 
	{
		System.out.println("Hello World!");
	}
}
