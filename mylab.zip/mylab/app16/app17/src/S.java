class S
{
	void test()
	{
		System.out.println("from test1");
	}
}
class T extends S
{
	public static void main(String[] args) 
	{
		T t = new T();
		t.test();
		System.out.println("Hello World!");
	}
}
