class B4 
{
	static int test(String s1)
	{
		try
		{
			return 2;
		}
		catch (NumberFormatException ex)
		{
			return 3;
		}
		return 4;
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
