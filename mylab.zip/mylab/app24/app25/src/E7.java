class E7 
{
	static int test7()
	{
		System.out.println(1);
		Object obj = new Object();
		E7 e1 = (E7)obj;//class cast exception
		return 2;
	}
	public static void main(String[] args) 
	{
		System.out.println(test7());
		System.out.println("Hello World!");
	}
}
