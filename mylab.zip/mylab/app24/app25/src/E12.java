class E12 
{
	static int test12()
	{
		class.forName();//produces class not found exception
		return 1;
	}
	public static void main(String[] args) 
	{

		System.out.println("Hello World!");
		System.out.println(test12());
	}
}
