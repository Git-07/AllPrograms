class E1 
{
	static int test2()
	{
		System.out.println(1);
		try
		{
			
		}
		catch (ArithmeticException ex)
		{
			
		}
		System.out.println(2);
		return 3;
	}
	public static void main(String[] args) 
	{
		System.out.println(test2());
		System.out.println("Hello World!");
	}
}
