class A2 
{
	static int test7(boolean flag)
	{
		if (flag)
		{
			return 1;
		}
		else 
		{
			System.exit(0);
			return 2;
		}
	}
	public static void main(String[] args) 
	{
		System.out.println(test7(true));
		System.out.println("Hello World!");
	}
}
