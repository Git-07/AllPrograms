class E2 
{
	static int test3()
	{
		System.out.println(1);
		int i = Integer.parseInt("add");//number format exception (unchecked exception)
		System.out.println(2);
		return 4;
	}
	public static void main(String[] args) 
	{
		System.out.println(test3());
		System.out.println("Hello World!");
	}
}
