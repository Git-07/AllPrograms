class A 
{
	static int test1()
	{
		try
		{
			
		}
		catch (ArithmeticException ex)
		{

		}
		return 1;
	}

	public static void main(String[] args) 
	{
		test1();
		System.out.println(test1());
	}
}
