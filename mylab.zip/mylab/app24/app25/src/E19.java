import java.sql.SQLException;
class E19 
{
	static int test19()
	{
	try
	{
		DriverManager.getConnection("");
	}
	catch (SQLException ex)
	{
	}
	return 2;
	}
	public static void main(String[] args) 
	{
		System.out.println(test19());
		System.out.println("Hello World!");
	}
}
