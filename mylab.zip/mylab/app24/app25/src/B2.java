class B2 
{
	static  int test(String s1)
	{
		try
		{
			
		}
		catch (ArithmeticException es)
		{
			return 2;
		}
		return 1;

	}
	public static void main(String[] args) 
	{
		System.out.println(test("mohit"));
	}
}
