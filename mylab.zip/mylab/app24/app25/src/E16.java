class E16 
{
	try
	{
		System.out.println(1);
	}
	catch (ClassNotFoundException ex)
	{
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
