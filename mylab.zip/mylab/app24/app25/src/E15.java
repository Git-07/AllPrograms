class E15 
{
	try
	{
		//there should be statements which cause classnotfoundexception
	}
	catch (ClassNotFoundException ex)
	{
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
