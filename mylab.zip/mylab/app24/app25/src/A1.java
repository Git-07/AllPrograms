class A1
{
	static int test(boolean flag)
	{
		if(flag)
		{
			return 2;
		}
		return 0;
	}
	public static void main(String[] args) 
	{

		System.out.println(test(true));
		System.out.println(test(true));
	}
}
