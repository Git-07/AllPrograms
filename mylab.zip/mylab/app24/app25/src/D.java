class D
{
	static int test1(String s1)
	{
		try
		{
			
		}
		catch (ArithmeticException ex)
		{
		}
		finally 
		{
		}
		return 12;
	}
	static int test2(String s2)
	{
		try
		{
			return 10;
		}
		catch (NullPointerException ex)
		{
			//if any excception arise in this block as finally retturn int 
			//value so no no cte  
		}
		finally
		{
			return 30;
		}
	}
	public static void main(String[] args) 
	{
		System.out.println(test1("mohit"));
		System.out.println(test2("latwal"));
	}
}
