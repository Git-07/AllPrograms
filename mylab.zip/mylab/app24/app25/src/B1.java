class B1 
{
	static int test(String s1)
	{
		try
		{
			
		}
		catch (NumberFormatException ex)
		{
			return 1;
		}
	}

	public static void main(String[] args) 
	{
		System.out.println(test("mohit"));
	}
}
