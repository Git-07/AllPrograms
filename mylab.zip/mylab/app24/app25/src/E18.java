class E18 
{
	void test18()
	{
	try
	{
		DriverManager.getConnection(""); 
	}
	catch (SQLException ex)
	{

	}
	}
}
