class E13 
{
	static int test13()
	{
		System.out.println(1);
		try
		{
			Class.forName("");//checked exception try and catch are mandatory
		}
		catch (ClassNotFoundException ex)
		{
			ex.printStackTrace();
		}
		return 2;
	}
		
	public static void main(String[] args) 
	{
		System.out.println(test13());
		System.out.println("Hello World!");
	}
}
