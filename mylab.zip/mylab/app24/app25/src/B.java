class B
{
	static int test(String s1)
	{
		try
		{
			
		}
		catch (ArithmeticException ex)
		{

		}  
		return 20;
	}
	static int test1(String s2)
	{
		try
		{
			return 1;
		}
		catch (NumberFormatException ex)
		{
			return 0;
		}
	}
	public static void main(String[] args) 
	{
		System.out.println(test("mohit"));
		System.out.println(test1("latwal"));
	}
}
