class E5 
{
	static int test5()
	{
		System.out.println(1);
		String s1 = null;
		s1.length();//null pointer exception (unchecked exception compiler is least bothering about try and catch)
		System.out.println(2);
		return 3;
	}
	public static void main(String[] args) 
	{
		System.out.println(test5());
		System.out.println("Hello World!");
	}
}
