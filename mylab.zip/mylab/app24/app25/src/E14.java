class E14 
{
	try
	{
		Class.forName();//checked exxception
	}
	catch (NullPointerException ex)
	{
		ex.printStackTrace();
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
