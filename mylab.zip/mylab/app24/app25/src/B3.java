class B3 
{
	static int test(String s)
	{
		try
		{
			return 2;
		}
		catch (NumberFormatException ex)
		{

		}
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
