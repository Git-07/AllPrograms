class E 
{
     static int test1()
	{
		System.out.println(1);
		int i = 10/0;
		System.out.println(22);
		return 10;
	}
	public static void main(String[] args) 
	{
		System.out.println(test1());
	}
}
