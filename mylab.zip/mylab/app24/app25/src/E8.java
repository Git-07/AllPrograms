class E8 
{
	static int test8()
	{
		test8();//recurrsion
		return 1;
	}
	public static void main(String[] args) 
	{
		System.out.println(test8());
		System.out.println("Hello World!");
	}
}
