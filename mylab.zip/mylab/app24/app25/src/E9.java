class E9
{
	static int test9()
	{
		try
		{
			
		}
		catch (StackOverflowError ex)//unchecked error
		{
			System.out.println(2);
	    }
		return 3;
	}
	public static void main(String[] args) 
	{
		System.out.println(test9());
		System.out.println("Hello World!");
	}
}
