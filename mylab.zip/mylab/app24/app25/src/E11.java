class E11 
{
	static int test11()
	{
		try
		{
			return 1;
			
		}
		catch (NoClassDefFoundError ex)
		{
			return 2;
		}
	}
	public static void main(String[] args) 
	{
		System.out.println(test11());
		System.out.println("Hello World!");
	}
}
