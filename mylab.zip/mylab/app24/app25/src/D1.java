class D1 
{
	static int test3(String s1)
	{
		try
		{
			
		}
		catch (ArithmeticException ex)
		{
		}
		finally
		{
			return 10;
		}
		//return 30; code unreachable 
	}
	public static void main(String[] args) 
	{
		System.out.println(test3("mohit"));
	}
}
