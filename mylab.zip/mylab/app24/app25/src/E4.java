class E4 
{
	static int test4()
	{
		System.out.println(1);
		try
		{
			
		}
		catch (NumberFormatException ex)//uchecked exception compiler is least bothering about try catch
		{
			System.out.println(2);
			System.out.println(ex);
		}
		return 3;
	}
	public static void main(String[] args) 
	{
		System.out.println(test4());
		System.out.println("Hello World!");
	}
}
