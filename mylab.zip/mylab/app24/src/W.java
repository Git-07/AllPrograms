class W 
{
	public static void main(String[] args) 
	{
		if(2==2)
		{
			return;
		}
		try
		{
			System.out.println(1);
			return;
		}
		catch (NumberFormatException ex)
		{
			System.out.println(ex);
		}
		finally 
		{
			System.out.println("finally");
		}
		System.out.println("Hello World!");
	}
}
