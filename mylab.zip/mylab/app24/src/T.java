import java.util.Scanner;
class T
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter some thing");
		String s1 = sc.next();
		try
		{
			System.out.println(1);
			int i = Integer.parseInt(s1);
			System.out.println(2);
			int k = i/(i-3);
			System.out.println(4);
		}
		catch (NumberFormatException ex)
		{
		    System.out.println(5);
			System.out.println(6);
			System.out.println(ex);
		}
		finally
		{
			System.out.println("finally");
		}
		System.out.println(7);
	}
}
