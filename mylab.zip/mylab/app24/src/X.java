class X 
{
	public static void main(String[] args) 
	{
		System.out.println(1);
		int i = Integer.parseInt("asd");//number format Exception
		System.out.println(2);
		try
		{
			String s1 = null;
			int k = s1.length();//null pointer exception 
		}
		catch (NullPointerException ex)
		{
			System.out.println(3);
			System.out.println(ex);
			System.out.println(4);
		}
		finally
		{
			System.out.println("finally");
		}
		System.out.println("Hello World!");
	}
}
