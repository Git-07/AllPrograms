class  B
{
	public static void main(String[] args) 
	{
		System.out.println(1);
		test();
		System.out.println(2);
		System.out.println("Hello World!");
	}
	static void test()
	{
		System.out.println(3);
		int i = 10/0;//arithmetic exception
		System.out.println(4);
	}
}
