class B1 
{
	public static void main(String[] args) 
	{
		test();
		System.out.println("Hello World!");
		System.out.println(test());
	}
	static int test()
	{
		return 12;
		return 13;
	}
}



