class F 
{
	public static void main(String[] args) 
	{
		System.out.println(122);
		E.print();
		System.out.println("Hello World!");
	}
}
