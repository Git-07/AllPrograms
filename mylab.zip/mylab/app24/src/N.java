class N 
{
	public static void main(String[] args) 
	{
		int i = 0;
		try
		{
			System.out.println(i); //no exception inside try
		}
		catch (ArithmeticException ex)
		{
			System.out.println(i);
		}
		System.out.println("Hello World!");
	}
}
