class J
{
	public static void main(String[] args) 
	{
		System.out.println(1);
		try
		{
			int i = 10/0;//it may cause an exception or exception bject
		}
		catch (ArithmeticException ex)//throwable
		{
			System.out.println(2);
			System.out.println(ex);
			System.out.println(3);
		}
		
		System.out.println(4);
		System.out.println("Hello World!");
	}
}
