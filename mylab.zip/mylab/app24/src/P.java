class P 
{
	public static void main(String[] args) 
	{
		System.out.println(1);
		try
		{
			System.out.println(2);
			int i = 10/0;//exception object
			System.out.println(3);
		}
		catch (ArithmeticException ex)
		{
			System.out.println(5);
			int j = 2/0;//no catch for this exception object			
			System.out.println(6);
		}
		System.out.println("Hello World!");
	}
}
