class Y 
{
	public static void main(String[] args) 
	{
		System.out.priniln(1);
		try
		{
			System.out.println(2);
			int i = 10/0;//arithmetic exception
			System.out.println(3);
		}
		catch (ArithmeticException ex)
		{
			System.out.println(4);
			System.out.println(ex);
			System.out.println(5);
			int j = 20/0;//arithmetic exception 
			System.out.println(6);
		}
		finally
		{
			System.out.println("finally");
		}
		System.out.println("Hello World!");
	}
}
