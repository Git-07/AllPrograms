class A1 
{
	public static void main(String[] args) 
	{
		int[] x = {1,2,3,4,5};
		System.out.println(11);
		int i = x[5];//array index outof bound exception
		System.out.println("Hello World!");
	}
}
