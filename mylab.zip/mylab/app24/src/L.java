class L 
{
	public static void main(String[] args) 
	{
		System.out.println(1);
		try
		{
			System.out.println(2);
			int i = 10/0;
			System.out.println(3);
		}
		catch (ArithmeticException ex)
		{
			System.out.println(4);
			System.out.println(ex);//type of exception and reason
			System.out.println(ex.getMessage());//reason for exception
			ex.printStackTrace();//what type of exception,reason for exception and position at which exception occurs
			System.out.println(5);
		}
		System.out.println("Hello World!");
	}
}
