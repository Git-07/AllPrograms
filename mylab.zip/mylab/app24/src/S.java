import java.util.Scanner;
class S 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter some thing");
		String s1 = sc.next();
		try
		{
			System.out.println(1);
			int i = Integer.parseInt(s1);//number format exception
			System.out.println(2);
			int k = i/(i - 9);//arithmetic exception
			System.out.println(3);
		}
		catch (ArithmeticException ex)
		{
			System.out.println(4);
			System.out.println(ex);//type and reason for exception
			System.out.println(ex.getMessage());//reason for exception
			System.out.println(5);
		}
		catch(NumberFormatException ex)
		{
			System.out.println(6);
			System.out.println(ex);
			System.out.println(ex.getMessage());
		}
		System.out.println("Hello World!");
	}
}
