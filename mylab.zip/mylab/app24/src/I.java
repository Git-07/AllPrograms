class I 
{
	public static void main(String[] args) 
	{
		System.out.println(1);
		int x[] = new int[999999999];
		System.out.println("Hello World!");
	}
}
