class M 
{
	public static void main(String[] args) 
	{
		try
		{
			int i = 10;
			System.out.println(i);
		}
		//catch (ArithmeticException ex)
		{
			System.out.println(2);
			System.out.println(1);
			System.out.println(2);
			System.out.println(4);
		}
 		System.out.println("Hello World!");
	}
}
