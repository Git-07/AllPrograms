class O 
{
	public static void main(String[] args) 
	{
		System.out.println(1);
		int i = 10/0;//terminate the flow
		try
		{
			System.out.println(1);
		}
		catch (ArithmeticException ex)
		{
			System.out.println(2);
		}
		System.out.println("Hello World!");
	}
}
