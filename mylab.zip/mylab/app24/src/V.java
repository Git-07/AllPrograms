class V 
{
	public static void main(String[] args) 
	{
		try
		{
			System.out.println(1);
			int k = 1/0;//flow will be sent to catch
			return;//becoz rest of the statements skipped
		}
		catch (ArithmeticException ex)
		{
			System.out.println(ex);
		}
		finally
		{
			System.out.println(3);
		}
		System.out.println("Hello World!");
	}
}
