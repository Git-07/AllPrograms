class Z3 
{
	static int i = test();
	static int test()
	{
		System.out.println("from test");
		return 10;
	}
}
