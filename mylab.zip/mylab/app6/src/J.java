class J 
{
	static int x =0;
	static void test1()
	{
		System.out.println("from test1:"+x);
	}
    static void testt2()
	{
		System.out.println("from test2:"+x);
		x = 2;
	}
	public static void main(String[] args) 
	{
		test1();
		System.out.println("main1:"+x);
		test2();
		System.out.println("main2:"+x);
	}
}
