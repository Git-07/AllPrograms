class B
{
	static int i;
	static double j;
	static boolean k;
	public static void main(String[] args) 
	{
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
	}
}
