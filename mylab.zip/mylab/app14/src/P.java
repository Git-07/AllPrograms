abstract class P 
{
	void test1()
	{
		System.out.println("hey");
	}
}
abstract class Q
{
	Q()
	{
		System.out.println("good day");
	}
}
class R extends P
{
}
class S extends Q
{
}
class T
{
	public static void main(String[] args) 
	{
		R r1 = new R();
		r1.test1();
		S s1 = new S();
		System.out.println("Hello World!");
	}
}
