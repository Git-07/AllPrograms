abstract class A1 
{
	abstract void test1();
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
class A2 extends A1
{
	void test1()
	{
		System.out.println("bye bye");
	}
	public static void main(String[]ar)
	{
		A2 a = new A2();
		a.test1();
	}
}
