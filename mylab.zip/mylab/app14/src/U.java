abstract class U 
{
	U()
	{
		System.out.println("yo yo");
	}
}

abstract class U1 extends U
{

}
class U2 extends U1
{
	public static void main(String[]ar)
	{
		U2 u = new U2();

	}

}