abstract class V
{
	V()
	{
		System.out.println("yo yo");
	}
}
abstract class W extends V
{
	W()
	{
		System.out.println("honey singh");
	}
}
class W1 extends W
{
	public static void main(String[] args) 
	{
		W1 w = new W1();
		System.out.println("Hello World!");
	}
}
