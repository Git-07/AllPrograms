abstract class H
{
	abstract void test1();
	abstract void test2();
	abstract void test3();
	void test4()
	{
		System.out.println("mohit");
	}
}
class I extends H 
{
	void test1()
	{
		System.out.println("oye");
	}
	void test2()
	{
		System.out.println("balle balle");
	}
	void test3()
	{
		System.out.println("hurray");
	}
	void test4()
	{
		System.out.println("yeah");
	}
	public static void main(String[] args) 
	{
		I i1 = new I();
		i1.test1();
		i1.test2();
		System.out.println("Hello World!");
	}
}
