abstract class J
{
	abstract void test1();
	abstract void test2();
	abstract void test4();
}
abstract class K extends J
{
	void test1()
	{
		System.out.println("from test1");
	}
	void test4()
	{
		System.out.println("from test4");
	}
}
class L extends K
{
	void test2()
	{
		System.out.println("from test3");
	}
	public static void main(String[] args) 
	{
		L obj = new L();
		obj.test1();
		System.out.println("Hello World!");
	}
}
