abstract class N
{
	N()
	{
		System.out.println("hey");
	}
	void test1()
	{
		System.out.println("from test1");
	}
}
class O extends N
{
	public static void main(String[] args) 
	{
		O o1 = new O();
		o1.test1();
		System.out.println("Hello World!");
	}
}
