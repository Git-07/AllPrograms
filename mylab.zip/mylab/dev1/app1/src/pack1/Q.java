package pack1;
class Q
{
	Q()
	{
		System.out.println("Q()");
	}
}
class R extends Q
{
	public static void main(String[] args) 
	{
		R r = new R();
		System.out.println("Hello World!");
	}
}
