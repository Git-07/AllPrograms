package pack1;
class A
{
	public static void main(String[] args) 
	{
		System.out.println("from pack1.A");
	}
}
