package pack1;
class L 
{
	private void test1()
	{
		System.out.println("hello");
	}
	void test2()
	{
		System.out.println("hi");
	}
}
class M extends L
{
	public static void main(String[] args) 
	{
		M m1 = new M();
		m1.test1();
		m1.test2();
		System.out.println("Hello World!");
	}
}
