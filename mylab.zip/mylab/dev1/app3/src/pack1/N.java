package pack1;
class N 
{
	private N()
	{
		System.out.println("blah-blah");
	}
	public static void main(String[] args) 
	{
		N n1 = new N();
		System.out.println("Hello World!");
	}
}
