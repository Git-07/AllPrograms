package pack1;
class Q
{
	private Q()
	{
		System.out.println("blah blah");
	}
	class R extends Q
	{
		public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
