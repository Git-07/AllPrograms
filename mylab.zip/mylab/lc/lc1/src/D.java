class D
{
	public static void main(String[] args) 
	{
		int i = diff(12);
		int j = diff(2);
		int k = diff(34);
		int l = diff(11);
		int m = diff(21);
		int n = diff(10);
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
		System.out.println(m);
		System.out.println(n);
	}
	static int diff(int n)
	{
		if(n<21)
		{
			return 21-n;
		}
		else
		{
			return 2*(n-21);
		}
	}
}
