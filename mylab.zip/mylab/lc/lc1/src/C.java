class C
{
	public static void main(String[] args) 
	{
		int i = out(1,2);
		int j = out(2,3);
		int k = out(3,4);
		int l = out(5,5);
		int m = out(5,6);
		int n = out(7,7);
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
		System.out.println(m);
		System.out.println(n);
	}
	static int out(int a , int b)
	{
		int sum = a+b;
		if(a==b)
		{
			sum = sum*2;
		}
		return sum;
	}
}