class A 
{
	public static void main(String[] args) 
	{
		boolean sleep = sleepIn(true,true);
		System.out.println(sleep);
	}
	static boolean sleepIn(boolean weekday,boolean vacation)
	{
		return(!weekday||vacation);
	}
}
