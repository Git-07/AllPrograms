class F 
{
	public static void main(String[] args) 
	{
		boolean i = out(2,5);
		boolean j = out(3,6);
		boolean k = out(5,5);
		boolean l = out(4,9);
		boolean m = out(3,6);
		boolean n = out(2,0);
		boolean o = out(2,10);
		boolean p = out(7,8);
		boolean q = out(9,2);
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
		System.out.println(m);
		System.out.println(n);
		System.out.println(o);
		System.out.println(p);
		System.out.println(q);
	}
	static boolean out(int a, int b)
	{
		if()
