class L
{
	public static void main(String[] args) 
	{
		String i = front("a");
		String j = front("ab");
		String k = front("abc");
		String l = front("how are");
		String m = front("jingle");
		String n = front("bell");
		String o = front("bhel");
		String p = front("abe");
		String q = front("hell0");
		String r = front("aja");
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
		System.out.println(m);
		System.out.println(n);
		System.out.println(o);
		System.out.println(p);
		System.out.println(q);
		System.out.println(r);
	}
	static String front(String str)
	{
		String s = null;
		if(str.length()>=3)
		{
			s = str.substring(0,3);
		}
		else
		{
			s = str;
		}
		return s+s+s;
	}
}
