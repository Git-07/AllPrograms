class B 
{
	public static void main(String[] args) 
	{
		boolean out1 = trouble(true,false);
		boolean out2 = trouble(true,true);
		boolean out3 = trouble(false,false);
		System.out.println(out1);
		System.out.println(out2);
		System.out.println(out3);
	}
	static boolean trouble(boolean i, boolean j)
	{
		if(i&&j)
		{
			return true;
		}
		if(!i&&!j)
		{
			return true;
		}
		else
		return false;
	}
}
