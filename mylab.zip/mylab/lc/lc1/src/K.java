class K 
{
	public static void main(String[] args) 
	{
		String i = mohit("code");
		String j = mohit("a");
		String k = mohit("ab");
		String l = mohit("abwe");
		String m = mohit("moijf");
		String n = mohit("hdggs");
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
		System.out.println(m);
		System.out.println(n);
	}
	static String mohit(String str)
	{
		if(str.length()==1)
		{
			return str;
		}
		char s1 = str.charAt(0);
		String s2 = str.substring(1,str.length()-1);
		char s3 = str.charAt(str.length()-1);
		return s3+s2+s1;
	}
}
