class M 
{
	public static void main(String[] args) 
	{
		String i = takeBack("cat");
		String j = takeBack("bat");
		String k = takeBack("mat");
		String l = takeBack("sat");
		String m = takeBack("a");
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
		System.out.println(m);
	}
	static String takeBack(String str)
	{
		char back = str.charAt(str.length()-1);
		return back + str + back;
	}
}
