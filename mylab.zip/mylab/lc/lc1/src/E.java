class E 
{
	public static void main(String[] args) 
	{
		boolean i = trouble(true,2);
		boolean j = trouble(false,3);
		boolean k = trouble(true,5);
		boolean l = trouble(true,21);
		boolean m = trouble(false,22);
		boolean n = trouble(false,25);
		boolean o = trouble(true,20);
		boolean p = trouble(false,24);
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
		System.out.println(m);
		System.out.println(n);
		System.out.println(o);
		System.out.println(p);
	}
	static boolean trouble(boolean talking,int hour)
	{
		if(talking&&(hour<7||hour>20))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
