class I
{
	public static void main(String[] args) 
	{
		String i = mohit("mohit");
		String j = mohit("not candy");
		String k = mohit("bad");
		String l = mohit("null");
		String m = mohit("sure");
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
		System.out.println(m);
	}
	static String mohit(String str)
	{
		StringBuffer sb = new StringBuffer(str);
		sb.deleteCharAt(int n);
		return sb.toString();
	}
}
