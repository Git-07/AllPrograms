class N 
{
	public static void main(String[] args) 
	{
		boolean i = tf(32);
		boolean j = tf(23);
		boolean k = tf(34);
		boolean l = tf(56);
		boolean m = tf(33);
		boolean n = tf(45);
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
		System.out.println(m);
		System.out.println(n);
	}
	static boolean tf(int n)
	{
		if(n%3==0||n%5==0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
