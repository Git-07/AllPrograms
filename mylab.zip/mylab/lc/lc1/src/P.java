class P 
{
	public static void main(String[] args) 
	{
		boolean i = mohit("hello");
		boolean j = mohit("hiperson");
		boolean k = mohit("hijack");
		boolean l = mohit("hola");
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
	}
	static boolean mohit(String str)
	{
		if(str.length()>=2)
		{
			String s = str.substring(0,2);
			return s.equals("hi");
		}
		return false;
	}
}


