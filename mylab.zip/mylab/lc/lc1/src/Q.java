class Q
{
	public static void main(String[] args) 
	{
		boolean i = temp(-1,345);
		boolean j = temp(121,-21);
		boolean k = temp(123,-123);
		boolean l = temp(0,123);
		boolean m = temp(122,122);
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
		System.out.println(m);
	}
	static boolean temp(int n, int x)
	{
		if((n<0&&x>100)||(n>100&&x<0))
		{
			return true;
		}
		return false;
	}
}
