class G 
{
	public static void main(String[] args) 
	{
		boolean i = mohit(122); 
		boolean j = mohit(134); 
		boolean k = mohit(100); 
		boolean l = mohit(200); 
		boolean m = mohit(12); 
		boolean n = mohit(234); 
		boolean o = mohit(12); 
		boolean p = mohit(111); 
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
		System.out.println(m);
		System.out.println(n);
		System.out.println(o);
		System.out.println(p);
	}
	static boolean mohit(int n)
	{
		if(90<=n&&n<=110||190<=n&&n<=210)
		{
			return true;
		}
		return false;
	}
}
