class J 
{
	public static void main(String[] args) 
	{
		String i = mohit("kitten",1);
		String j = mohit("mutton",4);
		String k = mohit("buttonoff",6);
		String l = mohit("shutter",2);
		String m = mohit("butter",0);
		String n = mohit("glitter",5);
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
		System.out.println(m);
		System.out.println(n);
	}
	static String mohit(String str,int n)
	{
	StringBuffer sb = new StringBuffer(str);
	sb.deleteCharAt(n);
	return sb.toString();
	}

}
