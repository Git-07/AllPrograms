class O 
{
	public static void main(String[] args) 
	{
		String i = front("kit");
		String j = front("shera");
		String k = front("tiger");
		String l = front("left");
		String m = front("tif");
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
		System.out.println(m);
	}
	static String front(String str)
	{
		String s = null;
		if(str.length()<=2)
		{
			s = str;
		}
		else
		{
			s = str.substring(0,2);
		}
		return s+str+s;
	}
}

