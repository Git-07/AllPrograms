class H 
{
	public static void main(String[] args) 
	{
		boolean i = mohit(1,1,true);
		boolean j = mohit(-1,-2,false);
		boolean k = mohit(-1,-2,true);
		boolean l = mohit(1,2,false);
		boolean m= mohit(-4,-5,true);
		boolean n = mohit(1,-2,false);
		boolean o = mohit(1,-3,true);
		boolean p = mohit(-2,-3,true);
		boolean q = mohit(2,-9,false);
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(l);
		System.out.println(m);
		System.out.println(n);
		System.out.println(o);
		System.out.println(p);
		System.out.println(q);
	}
	static boolean mohit(int n,int i,boolean b)
	{
		if(b&&((n>0&&i<0)||(n<0&&i>0)))
		{
			return true;
		}
		if((n<0&&i<0)||b)
		{
			return true;
		}
		return false;
	}
}

