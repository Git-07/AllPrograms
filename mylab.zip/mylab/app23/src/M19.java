class M19 
{
	public static void main(String[] args) 
	{
		String s1 = "p";
		boolean b1 = Boolean.parseBoolean(s1);//boxing and unboxing
		System.out.println(b1);
		char c1 = Character.parseChar(s1);//boxiing and unboxing
		System.out.println(c1);
		
	}
}
