class M48 
{
	static void test(int i)
	{
		System.out.println("int");
	}
	static void test(Byte b)//req reference of Byte object
	{
		System.out.println("byte");
	}
	static void test(Double d1)//req reference of Double object
	{
		System.out.println("double");
	}
	static void test(Number n1)//req reference of Number object
	{
		System.out.println("number");
	}
	static void test(Object obj)
	{
		System.out.println("object");
	}
	static void test(byte...b)
	{
		System.out.println("byte");
	}
	public static void main(String[] args) 
	{
		byte b1 = 10;
		test(b1);
		System.out.println("Hello World!");
	}
}
