class M6 
{
	public static void main(String[] args) 
	{
		String s1 = "9.789";
		Double d1 = new Double(s1);//boxing operation
		double d2 = d1.doubleValue();
		System.out.println("Hello World!");
		System.out.println(d2);
	}
}
