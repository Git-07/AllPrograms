class M17 
{
	public static void main(String[] args) 
	{
		String s1 = "9.8";
		float f1 = Float.parseFloat(s1);//boxing and unboxing
		double d1 = Double.parseDouble(s1);//boxing and unboxing
		System.out.println(f1);
		System.out.println(d1);
		int i1 = Integer.parseInt(s1);//boxing and unboxing
		System.out.println(i1);
	}
}
