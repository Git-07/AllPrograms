class M32 
{
	public static void main(String[] args) 
	{
		Boolean b1 = new Boolean(true);
		if (b1)//auto unboxing always requires boolean literal
		{
			System.out.println("done");
		}
		System.out.println("Hello World!");
	}
}
