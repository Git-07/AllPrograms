class M9 
{
	public static void main(String[] args) 
	{
		String s1 = "a";
		Character c1 = new Character(s1);//boxing operation
		char c2 = c1.charValue();//unboxing operation
		System.out.println("Hello World!");
		System.out.println(c2);
	}
}
