class M40 
{
	static void test(Float f1)//req float object reference 
	{
		System.out.println("float");
	}
	static void test(double d1)//req auto widening
	{
		System.out.println("double");
	}
	public static void main(String[] args) 
	{
		long l = 1222;
		test(l);
		System.out.println("Hello World!");
	}
}
