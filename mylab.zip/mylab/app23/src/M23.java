class M23 
{
	public static void main(String[] args) 
	{
		int i = 10;
		int j = new Integer(10);//autounboxing new Integer(10).intValue()
		System.out.println("Hello World!");
		System.out.println(j);
	}
}
