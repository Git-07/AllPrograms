class M8 
{
	public static void main(String[] args) 
	{
		String s1 = "true";
		String s2 = "false";
		String s3 = "asvd";
		Boolean b1 = new Boolean(s1);//boxing operation
		Boolean b2 = new Boolean(s2);//boxing operation
		Boolean b3 = new Boolean(s3);//boxing operation
		boolean b4 = b1.booleanValue();//unboxing operation
		boolean b5 = b2.booleanValue();//unboxing operation
		boolean b6 = b3.booleanValue();//unboxing operation
		System.out.println("Hello World!");
		System.out.println(b4);
		System.out.println(b5);
		System.out.println(b6);
	}
}
