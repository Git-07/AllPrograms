class M27 
{
		static void test(Integer obj)
		{
			System.out.println("done");
		}
		public static void main(String[] ar)
		{
			test(11);//autoboxing
		System.out.println("Hello World!");	
		}
}
