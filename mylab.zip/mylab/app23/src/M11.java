class M11 
{
	public static void main(String[] args) 
	{
		double d1 = 45.678;
		String s1 = "1212.121";
		Double d2 = Double.valueOf(d1);//boxing
		Double d3 = Double.valueOf(s1);//boxing
		Float f2 = Float.valueOf(s1);//boxing
		float f4 = f2.floatValue();//unboxing
		double d4 = d2.doubleValue();//unboxing
		double d5 = d3.doubleValue();//unboxing
		System.out.println("Hello World!");
		System.out.println(f4);
		System.out.println(d4);
		System.out.println(d5);
	}
}
