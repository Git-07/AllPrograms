class M14 
{
	public static void main(String[] args) 
	{
		int i = 10;
		String s1 = Integer.toString(i);
		double j = 10.9;
		String s2 = Double.toString(j);
		boolean k = true;
		String s3 = Boolean.toString(k);
		char c1 = 'a';
		String s4 = Character.toString(c1);
		System.out.println("Hello World!");
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		System.out.println(s4);
	}
}
