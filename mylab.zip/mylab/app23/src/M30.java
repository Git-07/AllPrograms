class M30 
{
	public static void main(String[] args) 
	{
		Double d1 = new Double(23);//boxing
		double d2 = 20;
		test(d1);
		test(d2);//autoboxing
		System.out.println("Hello World!");
	}
	static void test(Double obj)
	{
		System.out.println("done");
	}
}
