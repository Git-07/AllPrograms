class M7 
{
	public static void main(String[] args) 
	{
		String s1 = "12";
		Byte b1 = new Byte(s1);//boxing operation
		byte b2 = b1.byteValue();//unboxing operation
		System.out.println("Hello World!");
		System.out.println(b2);
	}
}
