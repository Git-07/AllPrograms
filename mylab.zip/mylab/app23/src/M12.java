class M12 
{
	public static void main(String[] args) 
	{
		boolean b1 = false;
		String s1 = "true";
		String s2 = "asdf";
		Boolean b2 = Boolean.valueOf(b1);//boxing
		Boolean b3 = Boolean.valueOf(s1);//boxing
		Boolean b4 = Boolean.valueOf(s2);//boxing
		boolean b5 = b2.booleanValue();//unboxnig
		boolean b6 = b3.booleanValue();//unboxing
		boolean b7 = b4.booleanValue();//unboxing
		System.out.println("Hello World!");
		System.out.println(b5);
		System.out.println(b6);
		System.out.println(b7);
	}
}
