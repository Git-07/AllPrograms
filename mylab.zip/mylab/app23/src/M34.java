class M34 
{
	static int test()
	{
		Integer obj = new Integer(20);//boxing
		return obj;//auto unboxing
	}
	public static void main(String[] args) 
	{
		Integer o1 = test();//auto boxing
		System.out.println("Hello World!");
		System.out.println(o1);//auto unboxing

	}
}
