class M22 
{
	public static void main(String[] args) 
	{
		Integer obj1 = new Integer(10);
		Integer obj2 = 10;//auto unboxing
		System.out.println("Hello World!");
		System.out.println(obj2);
	}
}
