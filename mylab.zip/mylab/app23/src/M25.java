class M25 
{
	public static void main(String[] args) 
	{
		Double d1 = new Double(20);//boxing
		double d2 = d1.doubleValue();//un boxing
		System.out.println(d2);
		System.out.println("Hello World!");
	}
}
