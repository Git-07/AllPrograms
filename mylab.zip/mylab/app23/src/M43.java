class M43 
{
	static void test(int...x)
	{
		System.out.println(x.length);//var arg is also an array
	}
	public static void main(String[] args) 
	{
		test();//zero integer argument
		test(1,2,3);
		test(1,2,3,4,5,6);
		System.out.println("Hello World!");
	}
}
