class M35 
{
	static void test(int i)
	{
		System.out.println("hi");
	}
	static void test(Integer obj)
	{
		System.out.println("bye");
	}
	public static void main(String[] args) 
	{
		int i = 20;
		Integer obj = new Integer(20);//boxing
		test(i);
		test(obj);
		System.out.println("Hello World!");
	}
}
