class M41 
{
	static void test()
	{
		System.out.println("test()");
	}
	static void test(int...arg)
	{
		System.out.println("test(var--args)");
	}
	public static void main(String[] args) 
	{
		test();
		test(12);
		test(10,30);
		test(1,2,3);
		test(1,2,3,4);
		System.out.println("Hello World!");
	}
}
