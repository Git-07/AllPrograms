class M39 
{
	static void test(Byte b)//req byte object reference
	{
		System.out.println("Byte");
	}
	static void test(int i)//req autoo widening
	{
		System.out.println("int");
	}
	public static void main(String[] args) 
	{
		byte b1 = 2;
		test(b1);
		System.out.println("Hello World!");
	}
}
