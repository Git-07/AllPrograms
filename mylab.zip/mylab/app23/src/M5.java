class M5 
{
	public static void main(String[] args) 
	{
		String s1 = "1000";
		Integer i = new Integer(s1);//boxing operation 
		int i1 = i.intValue();//unboxing operation
		System.out.println("Hello World!");
		System.out.println(i1);
	}
}
