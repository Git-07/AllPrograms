class M50 
{
	static void test(Double d1)
	{
		System.out.println("double");
	}
	static void test(Number n1)
	{
		System.out.println("number");
	}
	static void test(Object obj)
	{
		System.out.println("object");
	}
	static void test(byte...b)
	{
		System.out.println("byte");
	}
	public static void main(String[] args) 
	{
		byte b1 = 10;
		test(b1);//auto boxing then auto uppcasting
		System.out.println("Hello World!");
	}
}
