class M24 
{
	public static void main(String[] args) 
	{
		char c1 = new Character('s');//auto unboxing
		char c2 = 's';
		System.out.println(c1);
	}
}
