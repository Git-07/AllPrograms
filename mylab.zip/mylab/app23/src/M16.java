class M16
{
	public static void main(String[] args) 
	{
		String s1 = "45";
		byte b = Byte.parseByte(s1);
		int i = Integer.parseInt(s1);
		double d = Double.parseDouble(s1);
		long l = Long.parseLong(s1);
		System.out.println(b);
		System.out.println(i);
		System.out.println(d);
		System.out.println(l);
		System.out.println("hello hello hello");
	}
}
