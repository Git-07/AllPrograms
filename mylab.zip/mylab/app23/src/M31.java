class M31 
{
		static void test(Character obj)
		{
			System.out.println("done");
		}
		public static void main(String[] args)
	{
			test('a');
			char c1 = 't';
			test(c1);//auto boxing
			Character c2 = 'p';
			test(c2);//any version c2 is Character object
		System.out.println("Hello World!");
	}
}
