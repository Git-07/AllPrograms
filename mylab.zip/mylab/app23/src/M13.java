class M13 
{
	public static void main(String[] args) 
	{
		String s1 = "123gdd";
		Double d1 = Double.valueOf(s1);//boxing
		double d2 = d1.doubleValue();//unboxing
		System.out.println("Hello World!");
	}
}
