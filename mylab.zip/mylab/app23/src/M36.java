class M36 
{
	static void test(Integer obj)
	{
		System.out.println("integer");
	}
	public static void main(String[] args) 
	{
		int i = 20;
		Integer obj = new Integer(i);//boxing
		test(i);//autounboxing
		test(obj);
		System.out.println("Hello World!");
	}
}
