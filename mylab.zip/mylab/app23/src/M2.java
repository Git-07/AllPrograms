class M2 
{
	public static void main(String[] args) 
	{
		Double d1 = new Double(10.09);//boxing operation
		double d2 = d1.doubleValue();//unboxing operation
		System.out.println("Hello World!");
		System.out.println(d2);
	}
}
