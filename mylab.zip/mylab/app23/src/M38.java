class M38 
{
	static void test(double d1)
	{
		System.out.println("double");
	}
	static void test(Integer obj)
	{
		System.out.println("integer");
	}
	public static void main(String[] args) 
	{
		test(20);//auto widening
		System.out.println("Hello World!");
	}
}
