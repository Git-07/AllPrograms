class M37 
{
	static void test(int i)
	{
		System.out.println("int");
	}
	public static void main(String[] args) 
	{
		int i = 20;
		Integer obj = new Integer(i);
		test(i);
		test(obj);//autounboxing
		System.out.println("Hello World!");
	}
}
