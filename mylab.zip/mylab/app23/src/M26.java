class M26 
{
	public static void main(String[] args) 
	{
		int i = 2;
		Integer j = new Integer(i);//boxing
		int k = j.intValue();//unboxing
		Integer m = new Integer(i);
		System.out.println(i);
		System.out.println(k);
		System.out.println(j);
		System.out.println(m);
		System.out.println("Hello World!");
	}
}
