class M28 
{
	static void test(int i)
	{
		System.out.println("done");
	}
	public static void main(String[] args) 
	{
		Integer obj = new Integer(11);
		test(obj);//auto unboxing test(obj.intValue())
		System.out.println("Hello World!");
	}
}
