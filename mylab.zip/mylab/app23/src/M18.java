class M18 
{
	public static void main(String[] args) 
	{
		String s1 = "abgdf";
		String s2 = "true";
		boolean b1 = Boolean.parseBoolean(s1);//boxing and unboxing
		boolean b2 = Boolean.parseBoolean(s2);//boxing and unboxing
		System.out.println(b1);
		System.out.println(b2);
	}
}
