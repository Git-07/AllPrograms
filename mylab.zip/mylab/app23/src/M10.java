class M10 
{
	public static void main(String[] args) 
	{
		int i = 10;
		String s1 = "20";
		Integer obj1 = Integer.valueOf(i);//boxing
		Integer obj2 = Integer.valueOf(s1);//boxing
		int m = obj1.intValue();//unboxing
		int n = obj2.intValue();//unboxing
		System.out.println("Hello World!");
		System.out.println(m);
		System.out.println(n);
	}
}
