class M33 
{
	static Integer test(int i)//<--
	{//                          ' 
		return i;//auto boxing   '
	}//                          ---------------
	public static void main(String[] args)//    ' 
	{//                                         ' 
		byte b1 = 20;//                         '
		Integer obj = test(b1);//auto widening---
		System.out.println("Hello World!");
		System.out.println(obj);//auto unboxing
	}
}
