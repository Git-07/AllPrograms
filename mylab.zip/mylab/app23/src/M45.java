class M45 
{
	static void test(int x,String...y)
	{
		System.out.println(x);
		System.out.println(y.length);
	}
	public static void main(String[] args) 
	{
		test(12);
		test(1,"as");
		test(12,"bh","nj","mk");
		System.out.println("Hello World!");
	}
}
