class M1 
{
	public static void main(String[] args) 
	{
		int i = 0;
		Integer obj = new Integer(i);//boxing operation
		int k = obj.intValue();
		System.out.println("Hello World!");
		System.out.println(k);
	}
}
