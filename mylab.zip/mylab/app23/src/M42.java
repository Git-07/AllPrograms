class M42 
{
	static void test(String...str)
	{
		System.out.println("var strings");
	}
	public static void main(String[] args) 
	{
		test();//zero string argument
		test("abc");
		test("asd","qwer","zxc");

		System.out.println("Hello World!");
	}
}
