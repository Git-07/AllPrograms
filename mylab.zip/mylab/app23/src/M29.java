class M29 
{
	static void test(int i)
	{
		System.out.println("done");
	}
	public static void main(String[] args) 
	{
		Integer obj = new Integer(9);//boxing
		test(obj.intValue());
		System.out.println("Hello World!");
	}
}
