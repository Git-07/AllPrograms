class M44 
{
	static void test(String...var)
	{
		for(String s1:var)
		{
			System.out.print(s1+",");
		}
		System.out.println();
	}
	public static void main(String[] args) 
	{
		test("asd");
		test("hi","bye","see you");
		System.out.println("Hello World!");
	}
}
