class A 
{
	A(int i)
	{
		System.out.println("A");
	}
}
class B extends A
{
	B()
	{
		super(1);
		System.out.println("B");
	}
	public static void main(String[] args) 
	{
		A a1 = new A(1);
		System.out.println("Hello World!");
		B b1 = new B();
	}
}
