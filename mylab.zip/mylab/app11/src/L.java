class L 
{
	L()
	{
		super();
		System.out.println("hey hey");
		this(1);
	}
	L(int i)
	{
		super();
		System.out.println("hurrey");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
