class C 
{
	C(int i)
	{
		System.out.println("blah-blah");
	}
}
class D extends C
{
	D(int i)
	{
		super(2);
		System.out.println("good day");
	}
	public static void main(String[] args) 
	{
		C c1 = new C(1);
		System.out.println("Hello World!");
		D d1 = new D(2);
		System.out.println("balle balle");
		D d2 = new D(2);
		System.out.println("hurrey");

	}
}
