class J 
{
	static void test()
	{
		System.out.println("form J");
	}
	static
	{
		System.out.println("form sib-j");
	}
}
	class K extends J
	{
		static
		{
			System.out.println("form  test");
		}
	}
	class Manager5
	{
		public static void main(String[] args) 
	{
			K.test();//J.test()
			System.out.println("Hello World!");
	}
	}
