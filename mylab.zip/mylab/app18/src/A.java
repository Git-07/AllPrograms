class A 
{
	void test()
	{
		System.out.println("from A");
	}
}
	class B extends A
	{
		void test()
		{
			System.out.println("from B");
		}
	}
	class Manager1
	{
		public static void main(String[] args) 
		{
			A a1 = new A();
			B b1 = new B();
			A[]x = new A[2];
			x[0] = a1;
			x[1] = b1;
			for(int i = 0;i<x.length;i++)
			{
				x[i].test();
			}
			System.out.println("Hello World!");
		}
	}
