class L 
{
	static int i;
	static
	{
		System.out.println("form L-Sib");
	}
}
class M extends L
{
	static
	{
		System.out.println("form M sib");
	}
}
class Manager6
{
	public static void main(String[] args) 
	{
		System.out.println(M.i);//L.i
		System.out.println("Hello World!");
	}
}
