class E 
{
	void test()
	{
		System.out.println("from E test");
	}
}
class F extends E
{
	void test()
	{
		System.out.println("form F test");
	}
}
class G extends F
{
	void test()
	{
		System.out.println("form G test");
	}
}
class Manager3
{
	public static void main(String[] args) 
	{
		E e1 = new E();
		F f1 = new F();
		G g1 = new G();
		E e2 = new G();
		E e3 = new F();
		E []x = {e1,f1,g1,e2,e3};
		for(int i=0;i<x.length;i++)
		{
			x[i].test();

		}
		System.out.println("Hello World!");
	}
}
