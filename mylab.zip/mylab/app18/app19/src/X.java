class X 
{
	final int i ;
	X()
	{
		i = 0;
	}
	X(int j)
	{
		i = 19;
	}
	public static void main(String[] args) 
	{
		X x1 = new X();
		X x2 = new X(12);
		System.out.println(x1.i);
		System.out.println(x2.i);
	}
}
