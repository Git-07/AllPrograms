class Z1 
{
	final int i;
	Z1()
	{
		i = 10;
	}
	Z1(int i)
	{
		this.i = i;
	}
	public static void main(String[] args) 
	{
		Z1 z1 = new Z1();
		Z1 z2 = new Z1(12);	
		System.out.println(z1.i);
		System.out.println(z2.i);
	}
}
