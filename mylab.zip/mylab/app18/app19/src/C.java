class C 
{
	public static void main(String[] args) 
	{
		final int i = 10;
		i++;
		System.out.println(i);
	}
}
