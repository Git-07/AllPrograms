class Z5 
{
	final int i;
	Z5()
	{
		i = 12;
	}
	{
		i = 19;
	}
	public static void main(String[] args) 
	{
		Z5 z = new Z5();
		System.out.println("Hello World!");
	}
}
