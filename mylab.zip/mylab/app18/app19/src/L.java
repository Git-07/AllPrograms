class L
{
	public static void main(final String[] args) 
	{
		args[0] = "hello";
		System.out.println("Hello World!");
	}
}
