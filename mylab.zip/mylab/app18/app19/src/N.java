class N 
{
	final static int i =10;
	public static void main(String[] args) 
	{
		N n1 = new N();
		n1 = new N();
		N.i = 11;
		System.out.println(N.i);
	}
}
