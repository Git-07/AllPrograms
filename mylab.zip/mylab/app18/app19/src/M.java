class M
{
	public static void main(final String[] args) 
	{
		args = null;
		System.out.println("Hello World!");
	}
}
