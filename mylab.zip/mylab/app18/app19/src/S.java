class S 
{
	{
		x = 12;
	}
	final int x = 19;
	public static void main(String[] args) 
	{
		S s1 = new S();
		System.out.println(s1.x);
	}
}
