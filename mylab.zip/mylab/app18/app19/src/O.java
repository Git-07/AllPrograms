class O
{
	final static int i = 10;
	public static void main(String[] args) 
	{
		O o1 = new O();
		o1.i = 1;
		System.out.println(o1.i);
	}
}
