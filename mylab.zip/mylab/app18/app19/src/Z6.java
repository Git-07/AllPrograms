class  Z6
{
	static final int i = 10;
	static final String DRIVER = "some driver";
	public static void main(String[] args) 
	{
		System.out.println(i);
		System.out.println(DRIVER);
	}
}
