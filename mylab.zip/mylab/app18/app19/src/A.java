class A 
{
	public static void main(String[] args) 
	{
		final int i = 10;
		int j = 20;
		System.out.println(i);
		System.out.println(j);
		System.out.println(i);
		System.out.println(j);
		i = 10;
		j = 20;
		System.out.println(i);
		System.out.println(j);
	}
}
