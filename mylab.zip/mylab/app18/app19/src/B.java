class B 
{
	public static void main(String[] args) 
	{
		final int i;
		i = 10;
		System.out.println(i);
		System.out.println(i);
	}
}
