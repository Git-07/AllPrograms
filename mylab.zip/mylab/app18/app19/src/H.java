class H 
{
	public static void main(String[] args) 
	{
		final int [] x = new int[2];
		x[0] = 10;
		x[1] = 20;
		System.out.println("Hello World!");
	}
}
