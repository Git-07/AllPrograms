class G 
{
	public static void main(String[] args) 
	{
		final String s1 = "abc";
		s1 = "abc";
		System.out.println("Hello World!");
	}
}
