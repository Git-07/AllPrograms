class E 
{
	int i = 1;
	int j = 2;
	public static void main(String[] args) 
	{

		final E e1 = new E();
		System.out.println(e1);

	}
}
