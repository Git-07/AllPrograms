class R 
{
	final int i = 10;
	R()
	{
		i = 2;
		i = 23;
	}
	public static void main(String[] args) 
	{
		R r1 = new R();
		System.out.println(r1.i);
	}
}
