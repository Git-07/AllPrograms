class K 
{
	static void test(int i,final int j)
		 {
		   i = 10;
		   j = 2;
		  System.out.println(i);
		  System.out.println(j);
		}
	public static void main(String[] args) 
	{
		K k1 = new K();
		k1.test(1,2);
		
	}
}
