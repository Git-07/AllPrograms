class I 
{
	public static void main(String[] args) 
	{
		final int[] x = new int[3];
		x = null;
		System.out.println("Hello World!");
	}
}
