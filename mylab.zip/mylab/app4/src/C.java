class C 
{
	public static void test1()
	{
		System.out.println("from test1");
	}

	public static void main(String[] args) 
	{
		System.out.println("form main");
	}
	public static void test2()
	{
		System.out.println("from test2");
	}
}
