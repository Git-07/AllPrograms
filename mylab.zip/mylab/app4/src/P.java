class P 
{
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		if(100==100)
		{
			System.out.println("from if");
			return;
		}
		 System.out.println("main end");

     }
}
