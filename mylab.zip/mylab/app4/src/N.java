class N
{
	static void test()
	{
		System.out.println("test begiin");
		return;
		System.out.println("Hello World!");
	}
	public static void main(String[] args) 
	{
		test();
		System.out.println("Hello World!");
	}
}
