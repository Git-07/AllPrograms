class V 
{
	static void test()
	{
		System.out.println("form test");
	}
	public static void main(String[] args) 
	{
		System.out.println("test");
	}
}
