class R 
{
	static int test()
	{
		System.out.println("from test");
	}

	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		test();
	}

}
