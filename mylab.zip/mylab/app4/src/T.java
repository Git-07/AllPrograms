class T 
{
	static int test()
	{
		System.out.println("from test");
		return 10;
	}
	public static void main(String[] args) 
	{
		int i = 20;
		int j = 10 ;
		System.out.println(test());
		System.out.println(i);
		System.out.println(j);
		System.out.println(i + j + test());
	}
}