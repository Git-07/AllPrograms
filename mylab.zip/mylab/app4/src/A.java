class A 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		System.out.println("Hello World!");
		System.out.println("Hello World!");
		System.out.println("Hello World!");
	}
			public static void test()
			{
				System.out.println("from test");
			}
}
