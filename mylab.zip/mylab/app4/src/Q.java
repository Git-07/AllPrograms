class Q 
{
	public static void main(String[] args) 
	{
		if(true)
		{
			return;
		System.out.println("Hello World!");
		}
		System.out.println("Hello World!");
	}
}
