class J 
{
	static void test1() 
	{
		System.out.println("Hello World!");
	}
	static void test2()
	{
		J obj = new J();
		obj.test1();
		System.out.println("hi");
	}
}
