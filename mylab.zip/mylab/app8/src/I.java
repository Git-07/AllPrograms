class I 
{
	int x;
    static void test() 
	{
		I rv = new I();
		System.out.println(rv.x);
	}
}
