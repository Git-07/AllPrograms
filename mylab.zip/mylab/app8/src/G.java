class G
{
	int i;
	public static void main(String[]arg)
	{
		G g1 = new G();
		System.out.println(g1.i);
	}
}
