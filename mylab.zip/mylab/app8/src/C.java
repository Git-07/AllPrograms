class C 
{
    static int i = 10;
	public static int test() 
	{
		System.out.println(i);
		return i;
	}
}
