class E 
{
	static int i;
	static void test()
	{
		System.out.println(i);
	}
}
