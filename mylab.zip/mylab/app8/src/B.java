class B 
{
    void test()
	{
	}
	public static void main(String[] args) 
	{
		test();
		System.out.println("hello world");
	}
}
