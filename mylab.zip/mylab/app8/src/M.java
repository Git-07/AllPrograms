class M 
{
	int i;
	public static void main(String[] args) 
	{
		M m1 = new M();
		System.out.println(m1.i);
		m1.i = 10;
		System.out.println(m1.i);
	}
}
