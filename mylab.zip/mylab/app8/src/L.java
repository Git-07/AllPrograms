class L 
{
	int i = 10;
	void test1()
	{
		System.out.println("hello");
	}
	static 
	{
		L obj = new L();
		obj.test1();

	}
}
