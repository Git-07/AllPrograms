class C 
{
	@Deprecated
	static void test1()
	{
		System.out.println("test1");
	}
	static void test2()
	{
		System.out.println("test2");
	}
	public static void main(String[] args) 
	{
		test1();
		test2();
		System.out.println("Hello World!");
	}
}
