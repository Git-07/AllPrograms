import java.util.ArrayList;
@SuppressWarnings({"unchecked","deprecation"})
class Manager5 
{
	public static void main(String[] args) 
	{
		ArrayList list = new ArrayList();//unchecked
		list.add(34);
		Thread t1 = new Thread();
		t1.stop();//deprecated
		System.out.println("Hello World!");
	}
}
