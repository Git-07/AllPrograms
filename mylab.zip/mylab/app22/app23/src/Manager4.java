import java.util.ArrayList;

class Manager4 
{
	public static void main(String[] args) 
	{
		ArrayList list = new ArrayList();//uncheked
		list.add(90);
		list.add(90);
		System.out.println("Hello World!");
	}
}
