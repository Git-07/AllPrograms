class Manager1 
{
	public static void main(String[] args) 
	{
		C c1 = new C();
		c1.test1();//we are getting only warning but we can run
		c1.test2();
		System.out.println("Hello World!");
	}
}
