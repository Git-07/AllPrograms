class Manager2 
{
	public static void main(String[] args) 
	{
		Thread t1 = new Thread();
		t1.stop();//gives a warning
		System.out.println("Hello World!");
	}
}
