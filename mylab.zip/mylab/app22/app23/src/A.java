class A
{
	static void test1()
	{
		System.out.println("A-test1");
	}
}
class B extends A
{
	@override
	static void test1()
	{
		System.out.println("B-test1");
	}
	static void test2()
	{
		System.out.println("B-test2");
	}
	public static void main(String[] ars)
	{
		test1();
		test2();
	}
}

