import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
@Retention(RetentionPolicy.RUNTIME)
@interface Author
{
	String name() default"don";
}
@Retention(RetentionPolicy.RUNTIME)
@interface Version
{
	double number();
}
@Author(name = "mohit")
@Version(number = 10.0)
class S 
{
	@Author(name = "latwal")
    @Version(number = 2.9)
	void annotateMethod1() 
	{
		System.out.println("Hello World!");
	}
	@Version(number = 2.5)
	public static void main(String[] args)
	{
		System.out.println("Bye world");
	}
}
