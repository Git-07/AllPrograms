@interface F  
{
	public String someMessage();
}
class G
{
	@F(someMessage = "My  first anntation program")
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
