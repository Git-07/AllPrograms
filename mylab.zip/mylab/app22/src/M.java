@interafce M  
{
	public String message();
	public boolean flag();
}
@M(message = "mohit",flag = true)
class K
{
	@M(message = "Latwal",flag = true)
		int m;
	@M(message = "Almora",flag = true)
		K()
	{
		System.out.println("you are in K()");
	}
	//annotated description is not available
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
