import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
@Target(ElementType.FIELD)
@interface Ann4
{
	public String someMessage();
}
class O
{
	@Ann4(someMessage = "mohit")
		int m;
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
