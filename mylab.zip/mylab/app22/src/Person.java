import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
@Retention(RetentionPolicy.RUNTIME)
@interface Person
{
	public String personFirstName();
	public String personLastName();
	public String personEmailId();
	public String personAddress()default "Bangalore";
	public int personAge()default 20;
}
@Person(personFirstName = "abc",personLastName = "xyz",personEmailId = "jamesbond@oo7")
class R
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
