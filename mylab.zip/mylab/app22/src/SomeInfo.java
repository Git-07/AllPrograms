@interface SomeInfo 
{
	public String someMessage();
}
@SomeInfo(someMessage="hey")
class H
{
	@SomeInfo(someMessage="balle-balle")
		int i;
	@SomeInfo(someMessage="about me")
	H()
	{
		System.out.println("you are in H()");
	}
	@SomeInfo(someMessage="party in main")
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
