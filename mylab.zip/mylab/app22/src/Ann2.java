@interface Ann2
{
	public int countValue();
	public String someMessage()default "abc";
}
@Ann2(countValue = 1)
class Z
{
	@Ann2(countValue = 2,someMessage = "asd")
		int m;
	@Ann2(countValue = 3)
		Z()
	{
		System.out.println("you are in Z()");
	}
	@Ann2(countValue = 0)
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
