@interface Test  
{
	public String message();
	public boolean flag();
}
@Test(message = "some info",flag = true)
class J
{
	@Test(message = "here again",flag = false)
		int m;
	@Test(message = "again and again",flag = true)
		J()
	{
		System.out.println("you are in J()");
	}
	@Test(message = "time repeats itself",flag = false)
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
