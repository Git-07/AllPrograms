@interface Ann1
{
	public int countValue()default 1;
	public String someMessage()default "abcd";
}
@Ann1(countValue = 2)
class L
{
	@Ann1
	int m;
	@Ann1(countValue = 3,someMessage = "asdf")
	L()
	{
		System.out.println("you are in L()");
	}
	@Ann1(someMessage = "Mohit")
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
