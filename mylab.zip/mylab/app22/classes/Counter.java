@interface Counter 
{
	public int count();
}
@Counter(count = 1)
class I
{
	@Counter(count = 2)
		int m;
	@Counter(count = 3)
		I()
	{
		System.out.println("you are in I()");
	}
	@Counter(count = 4)
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
