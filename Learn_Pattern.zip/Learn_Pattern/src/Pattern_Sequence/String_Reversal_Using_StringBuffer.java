package Pattern_Sequence;
import java.util.*;

// checking of a String Palindrome or not
public class String_Reversal_Using_StringBuffer {
	
	
	public static void main(String[] a){
		String m = "NAAN"; // Literal way of creating objects
		String n = "Mohit".concat(m);
		String v = "2017";
		int i = 2018;
		m = "Mohit";
		System.out.println(m.replace("N", "o")); 
		StringBuffer s = new StringBuffer("mmm"); 
		StringBuilder sfr = new StringBuilder(m);		
		System.out.println(sfr.append(" Latwal"));
/*		System.out.println(Integer.parseInt(v));
		System.out.println(Integer.valueOf(v));
		System.out.println(Integer.toString(i));
		System.out.println(String.valueOf(i)); */
		
		System.out.println(m == n);
		//String s1 = new String("Mohit");
		//s1.concat("Latwal");
		//System.out.println(s1);
		System.out.println(sfr.reverse());
		StringBuilder reverse = new StringBuilder(sfr);
		reverse.reverse();
		if(sfr.toString().equals(reverse.toString())){
			System.out.println("Palindrome");
		}
		else{
			System.out.println("not a Palindrome");
		}
			
		
		
	}

}
