package Pattern_Sequence;

public class Sort_Array_Using_Same {
	
	
	public static void main(String[] args){
	
		int arr[] = {2, 0, 3, 5, 1, 6, 0};
		int temp ;
		for(int i = 0 ; i < arr.length; i++){
			for(int j = i +1; j< arr.length; j++){
				
				if(arr[i] > arr[j]){
					temp = arr[i]; // it will store 0
					arr[i] = arr[j]; // ith position will get 0;
					arr[j] = temp; // jth position will get ith position value;
					// after first iteration we will get
					//{0,2,3,5,1,6,9}					
				}				
			}
		}
		
	 for(int k =0 ; k < arr.length ;k++){
		 System.out.print(arr[k]);
	 }	
	}
}
