package Pattern_Sequence;
import java.util.*;
public class Remove_Duplicates {
	public static void main(String[] a){
		
/*	//Scanner scan = new Scanner(System.in);
	System.out.println("Enter the sentence");
	//String sentence = scan.next();
    String sentence = "mohIT Ia  the mohit kakak the mohit mohit  the mohit the the the mohit MOHIT  MOHit moHIT";
	String sentenceArray[] = sentence.split("\\s+");	
	List<String> listString = new ArrayList<String>();
	 int flag = 0;	
	String withoutRepeated[] = new String[sentenceArray.length];
	if(sentenceArray.length > 0){
		listString.add(sentenceArray[0].toString());
		for(int i= 1; i<sentenceArray.length;){
					       if(listString.size()> 0){
					     		   for (String m : listString) {
//					    	   for (String m : withoutRepeated) {
					     			  //if(m.contentEquals(sentenceArray[i].toString())){
					     			  if(m.equalsIgnoreCase(sentenceArray[i].toString())){
							        		//	System.out.println("djhbdcehjbdcehjbdcehbj");					        			
						        			flag = 0;
				                            break;
						     		   }                                 
					     			 //else if(!m.contentEquals(sentenceArray[i].toString())){
					     			 else if(!m.equalsIgnoreCase(sentenceArray[i].toString())){
						        		//	System.out.println("djhbdcehjbdcehjbdcehbj");					        			
					        			flag = 1;			
					     		   }
					        	}
					        }
					       if(flag == 1){
					       listString.add(sentenceArray[i].toString());
					      }
                  i++;
	}
	     for (String m : listString) {
		        System.out.println(m);		        
		  } 	       
	}
	Collections.sort(listString);
	System.out.println(listString);*/
		
		
  String words[] = {"Mysore", "Mysore","Mysore","Mysore","Mysore","Mysore","Mysore","Mysore","India"};
  int counter = 0;
  int flag = 0;
  String withoutRepeated [] = new String [words.length];
  withoutRepeated[counter] = words[0];
  for(int i = 0 ;  i < words.length ;){
    	  for(int j =0 ; j< withoutRepeated.length; j++){
    		  
    		  if(withoutRepeated[j] == words[i]){ // to references of same object 
    			  flag = 1;
    			  break;
    		  }
    		  else if(withoutRepeated[j] != words[i]){ // to check two references of same object
    			  flag = 2;
    			  
    		  }    		  
    	  }
    if(flag == 2){
    	++counter;
    	withoutRepeated[counter] = words[i];
    	flag = 0;
    }	  
    	
    ++i;	  	  
    	  
  }
  
  for(int k = 0 ; k<=counter ; k ++){
	  System.out.println(withoutRepeated[k]);
  }
}

}	
