
/* USE OF HASHMAP */
package Pattern_Sequence;
import java.util.Map.*;
import java.util.*;
public class FindDuplicateAndTheirCount {
	
	public static void main(String[] a){
	String duplicateWords = "Read read butter bread butter butter bread";
	
	String[] words  = duplicateWords.split(" ");	
	HashMap<String, Integer> wordCount = new HashMap<String, Integer>();
	
	for(String word : words){
     if(wordCount.containsKey(word)){ // .containsKey(String arg) -> it will return a boolean if sent word is there.
    	 
    	 wordCount.put(word, wordCount.get(word)+1); // .get(String arg) -> it will give count 1 .If sent word is there
     }	
     else{
    	 
    	 wordCount.put(word, 1);
     }		
	} 
	System.out.println(wordCount);
	
	for(Entry<String, Integer> pair : wordCount.entrySet()){
		System.out.println(pair.getKey() + "-->" + pair.getValue());
	}
	
	System.out.println("Duplicates with their count with the help of entrySet()");
	 Set<Entry<String,Integer>> enteries = wordCount.entrySet();
     System.out.println( enteries);
	//Set<String> wordsInString = wordCount.keySet();
/*	System.out.println("Duplicates in the sentence");
	for(String word : wordsInString){
		
	if(wordCount.get(word) > 1){
		
	System.out.println(word);
	}
	}
	System.out.println("Duplicates with their counts with the help of keySet()");	
	System.out.println(wordsInString);

	for(String word : wordsInString){
		
		if(wordCount.get(word) > 1){
			System.out.println(word  +" : " + wordCount.get(word));
		}
	}*/

    
	
/*	Collection<Integer> values = wordCount.values();
	System.out.println(values);*/
}

}

/*[bread, butter, read]
bread : 2
butter : 3
read : 1
[bread=2, butter=3, read=1] as a json
[2, 3, 1]

 * price map: {Car=20000, Phone=200, Bike=6000, Furniture=700, TV=500} 
 * keys of Map : [Car, Phone, Bike, Furniture, TV] 
 * values from Map :[20000, 200, 6000, 700, 500] 
 * entries from Map :[Car=20000, Phone=200, Bike=6000, Furniture=700, TV=500]
 
*/

