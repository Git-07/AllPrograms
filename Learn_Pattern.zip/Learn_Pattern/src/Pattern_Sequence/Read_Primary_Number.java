package Pattern_Sequence;
import java.util.*;

public class Read_Primary_Number {
	
	//********* Read the prime numbers in the given range *******************//
	public static void main(String[] a){
	//int prime[] = {2,3,5,7,11,13,17};
	int c = 2;
    int b = 50000;
    int flag = 0 ;
    ArrayList<Integer> intArr = new ArrayList<Integer>();
    
    for(int i = c ; i <= b ;i++){
    	for(int j =2; j <i ;j++){
    		if(i == 2){
    			intArr.add(2);
    		}  		
    		if(i % j == 0 ){    			   	
    			flag = 1;    			
    			break;
    		}
       	   else if(i%j !=0){
    		 flag = 2;
    	 } 
    	}
        if(flag == 2){     	   
        	intArr.add(i);    	   
        }
    }
      System.out.print(intArr);
	}
}
