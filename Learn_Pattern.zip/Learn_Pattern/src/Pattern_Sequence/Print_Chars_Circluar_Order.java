package Pattern_Sequence;

public class Print_Chars_Circluar_Order {

	public static void main(String[] args){	
	String str ="factset";
	char[] ch = str.toCharArray();
	int k = 0;
	int i = 0;
	for(; i < ch.length ;){			
		
		for(int j = i+1; j< ch.length ; j++){
			
			System.out.print(ch[j]);
		}
		i++;
		k = i;
		for(int l = 0 ; l< k ; l++){
			System.out.print(ch[l]);
		}
		System.out.println();
	}
}
}
