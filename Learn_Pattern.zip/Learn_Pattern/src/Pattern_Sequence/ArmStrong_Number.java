package Pattern_Sequence;
import java.util.*;

public class ArmStrong_Number {	
	public static void main(String[] args){		
	/*	int a = 371;
		int sum = 0;
		int x=0;
	    ArrayList<Integer> list = new ArrayList<Integer>();
		    while(a%10 !=0){		
			System.out.println(Math.abs(a/10)); // using Math.abs gives absolute value
		  //  System.out.println((int)Math.round(a/10)); // using casting to int Math.round give the round off int value
			list.add(Math.abs(a%10));
			System.out.println(Math.abs(a%10));
			a = a/10;
		}		
		for(int i =0 ;i <list.size();i++){
			for(int j = 0 ; j<list.size()-1 ;j++){				
				if(x == 0){ 
				x = list.get(i)*list.get(i);				 
				}
				else if(x != 0){
			   x =  x * list.get(i);
				}			
			}			
			sum = sum + x;
			x = 0;
		}		
	
		System.out.println("bhjabchkdbc" + sum);			    	
	}*/
  int sum = 0;
  int number = 371;
  int temp = number;
  int x;
 // Scanner scan = new Scanner(System.in);
  //number = scan.nextInt();

  while(number>0){	  
	  x = number%10;
	  number = number/10;
	  sum = sum + x*x*x;
  }
  if(temp == sum){
  System.out.println(sum);
  }
}
}
