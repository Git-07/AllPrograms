package Pattern_Sequence;
import java.util.*;
public class Missing_Number_In_Range {
	
	public static void main(String[] a){
		int flag = 0;
		int n = 8;
		int[] b = {11,12,13,14,15,7,11};
		ArrayList<Integer> list = new ArrayList<Integer>();
		for(int i = 1; i<=n; i++){
			for(int c = 0 ; c< b.length ;c++){
				if(b[c] == i){
					flag =1;
					break;
				}
				else if((b[c] != i)){
					flag = 2;
				}
			}
			if(flag ==2){
				list.add(i);
			}
		}
			System.out.println(list);			
	}

}
