package Pattern_Sequence;
import java.util.*;
public class Print_Number_Pattern4 {
	
	public static void main(String[] arg){	
		int n = 6;		
		for(int i = 1 ;i<=n;i++){
			int count = i;
			if(i%2 == 0){
			System.out.print(++count);
			}
			for(int j =1; j<=n; j++){
			System.out.print(i);
			}
			if(i%2 !=0){
			System.out.print(++count);
			}
			System.out.println();
		}		
	}
}
