package JavaCollections;
import java.util.*;

class Employee_Details implements Comparable<Employee_Details> {
	
	String name;
	int salary;
	Employee_Details(String name, int salary){
		this.name = name;
		this.salary = salary;
	}
	public void setName(String name){
		this.name= name;
	}
	public String getName(){
		return name;
	}
    public void setSal(int salary){
    	this.salary = salary;
    }
    public int getSal(){
    	return salary;
    }
	@Override
	public int compareTo(Employee_Details obj) {
	
/*		if(this.getSal() == obj.getSal()){
		return 0;
		}
		else if(this.getSal() < obj.getSal()){
			return 1;
		}
		else {
			return -1;
		}*/
		
		return(obj.getSal() - this.getSal());
		//return (this.getName().compareTo(obj.getName()));
	
	}
	

}

public class Sort_Employee {
	
	public static void main(String[] args) {
    
		List<Employee_Details> tree = new ArrayList<Employee_Details>();		
		tree.add(new Employee_Details("ABC",212112));
		tree.add(new Employee_Details("EFG",21323121));
		tree.add(new Employee_Details("JKL",546456));
		tree.add(new Employee_Details("MNO",546564564));
		
		System.out.println("Employee Name" + "  " + "Employee Salary");		
		
		Iterator<Employee_Details> itr = tree.iterator();		        
		while(itr.hasNext()){
     		Employee_Details empObj = (Employee_Details)itr.next();			
			System.out.println(empObj.getName() + "  " + empObj.getSal());
			
		}
		
	}	
}
