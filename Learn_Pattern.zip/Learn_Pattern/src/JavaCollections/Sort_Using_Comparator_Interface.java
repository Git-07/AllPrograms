package JavaCollections;
import java.util.*;

class Employee{
	 String name;
	 int salary;
	 int age;
	 Date doj;	
	Employee( String name, int salary, int age, Date doj){
		this.name  =  name;
		this.salary = salary;
		this.age = age;
		this.doj = doj;
		
	}
}
class AgeComparator implements Comparator<Employee>{			
	
		public int compare(Employee o1 , Employee o2){			
			return (o1.age - o2.age);
		 }
	} 

class SalaryComparator implements Comparator<Employee>{
	
	public int compare(Employee o1 , Employee o2){
		return  (o1.salary - o2.salary);
	}
}
class NameComparator implements Comparator<Employee>{
	
	public int compare(Employee o1 , Employee o2){
		return ( o1.name.compareTo(o2.name));
	} 
}
class DateOfJoiningComparator implements Comparator<Employee>{
	
	
	public int compare(Employee o1 , Employee o2){
		
		return o1.doj.compareTo(o2.doj);
	}
}
public class Sort_Using_Comparator_Interface {

	    public static void main(String[] ar){
	    	
	    	List<Employee> employeeList = new ArrayList<Employee>();
	    	
	    	employeeList.add(new Employee ("Kate", 2121, 25, new Date (2018, 02, 1)));
	    	employeeList.add(new Employee ("Marium", 1212, 21, new Date (2018,01,1)));
	    	employeeList.add(new Employee ("Ajay", 2132, 30, new Date (2016,06,9)));
	    	employeeList.add(new Employee ("Dave", 222, 20, new Date(2018,06,3)));
	    	
	    	System.out.println("Sorting by name :");	    	
	    	Collections.sort(employeeList,new AgeComparator());	    	
	    	Iterator itr = employeeList.iterator();
	    	while(itr.hasNext()){
	    		Employee obj = (Employee)itr.next();
	    		System.out.println(obj.name + "  " + obj.age + "  " + obj.salary + "  " + obj.doj);
	    	}
	    }
}
