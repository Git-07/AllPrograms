package Same_Array_Pattern;

public class ArmStrong_Number {
	
	public static void main(String[] ar ){
		
		int number = 371;
		int temp = 0;
		int armStrong = number;
		while(armStrong>0){
			
			int remainder = armStrong%10;
			temp = temp + remainder*remainder*remainder;
			armStrong = armStrong/10;								
		}
		if(temp == number){
		System.out.println(temp);
		System.out.println("Number is ArmStrong Number");
	   }
	}
}
