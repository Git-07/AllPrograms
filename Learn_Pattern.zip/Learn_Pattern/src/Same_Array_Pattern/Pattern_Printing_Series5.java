package Same_Array_Pattern;

public class Pattern_Printing_Series5 {
	
	static char ch = 'a';
	static int a = (int) ch;
	static int  row = 4; 
	public static void main(String[] ar){
	
		for(int r =1 ; r<= row; r++){
			
			for(int j = r ;j< row ;j++){
				
				System.out.print(" ");				
			}
			
			for(int c =1 ; c<=r; c++){
				System.out.print(ch);
				System.out.print(" ");
			}
			a++;
			ch = (char) a;
			System.out.println();
		}			
	}

}
