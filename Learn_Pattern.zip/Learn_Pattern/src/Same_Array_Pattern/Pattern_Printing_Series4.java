package Same_Array_Pattern;

public class Pattern_Printing_Series4 {

	public static void main(String[] ar){
		
		int counter;
		int row = 4;
		
		for(int r = 1; r<= row; r++){
			
			counter = r;
			for(int i =1; i<=2*row - 2*counter;i++){
		
				System.out.print(" ");
			}
			
			for(int c =1 ; c<=r ;c++){
				System.out.print(r);
				if(c!=r){
				System.out.print("---");
				}
			}			
			System.out.println();
		}
	}
	
}
