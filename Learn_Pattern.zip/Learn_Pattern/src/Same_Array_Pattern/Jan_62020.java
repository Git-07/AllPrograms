package Same_Array_Pattern;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Jan_62020 {

	public static void main(String [] ar) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		
		Jan6_2020_PrivateMethod pm = new Jan6_2020_PrivateMethod();
		Method m = Jan6_2020_PrivateMethod.class.getDeclaredMethod("privateMethod");
		m.setAccessible(true);
		int a = (int) m.invoke(pm);
		System.out.println(a);
	}
}

