package Same_Array_Pattern;
public class AssignValueWithoutThird extends Thread{
	public static void main(String[] s) throws Throwable {
		AssignValueWithoutThird t = new AssignValueWithoutThird();
		//t.finalize();
		int x = 2;
		int y = 7;
		long a = 10;
		x = x + y;
		y = x - y;
		x = x - y;
		System.out.println(x);
		System.out.println(y);
		System.out.println(a);
	
		//t.run();
	}

/*	static {

		System.out.println("ndlknadvlk");
	}

	static {
		System.out.println("execute this 1st");
	}*/
}
