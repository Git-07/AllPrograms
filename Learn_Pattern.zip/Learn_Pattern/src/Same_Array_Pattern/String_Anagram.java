package Same_Array_Pattern;

public class String_Anagram {
	
	static char temp = ' ';     
	public static String getTheSortedChars(char[] ch){
		String str="";
		for(int i=0; i<ch.length ; i++){
			for(int j = i+1 ; j<ch.length ; j++){
				
				if((int) ch[i] > (int) ch[j]){
					temp = ch[i];
					ch[i] =  ch[j];
					ch[j] = temp;
				}
			}
		}
		return str.valueOf(ch);
		
	}
	public static void main(String[] ar) {
        
		int flag = 0;
		String word1 = "He,qw1234e,ll";
		String word2 = "He,qw1234le,a";
		
		if(word1.length() != word2.length()){
			System.out.println("String are not Anagram");
		}/* else{

		for(int k = 0; k<getTheSortedChars(word1.toCharArray()).length ;k++){

	           if(getTheSortedChars(word1.toCharArray())[k]== getTheSortedChars(word2.toCharArray())[k]){
				flag = 1;
			}
			
			else {
				flag = 2;
				break;
			}
		}*/
/*       if(flag == 1){
    	   System.out.println("String are anagram");
       }else {
    	   System.out.println("String are not Anagram");
       } */	   
		if(getTheSortedChars(word1.toCharArray()).equals(getTheSortedChars(word2.toCharArray()))){
			
			System.out.println("Stirng are anagram");
		}
		else{
			System.out.println("Strings are not anagram");
		}
		}

}
