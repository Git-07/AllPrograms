package Same_Array_Pattern;
public class Count_Repeated_Words_Without_HasMap {
	// this program is to print single if duplicates are present
	// this program is also for printing the count of duplicates
	public static void main(String[] arg){
	String[] words = {"Bengaluru","abcd","aa","Mysore","Ooty","Mysore","ABC","AbC","ABC"};
	int counter =1;	
	for(int i = 0 ; i<words.length; i++){
		
		for(int j = i+1; j<words.length; j++){
			
			if(words[i] == words[j]){
				++counter;
				words[j] =""; // this has been erased so even if the last one has already detected so it will not make 
			}                 // any impact becoz of the if condition where no blanks are getting printed
		}
		if(!words[i].equals("")){
		System.out.println("Count of " + words[i] + " equals :" + counter);
		//System.out.println(word + " ");
		}
		counter =1;
	}

 }
}