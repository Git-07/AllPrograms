package Same_Array_Pattern;

public class Filter_Prime_Number {

	public static void main(String [] ar){
		
		int num [] = {2,8,6,11,2,2,2,2,8,13,19,27,3,91};
/*		int flag = 0; 
		int count = 0;
		
		for (int i = 0 ; i< num.length ;i ++){			
			
			if(num[i] == 2){
				
				num[count] = num[i];
				++count;				
			}
	       else if (num[i] != 2){
			 for(int j = 2 ;j < num[i] ; j++){				
			  
				if(num[i] % j == 0){
					flag = 1;
					break;
				}
		   else if (num[i] % j != 0){
			 flag = 2;
		   }	
		}
	}
	if (flag == 2){
		
		num[count] = num[i];
		++count;
		flag = 0;
	}		
}
		
	for(int k = 0 ; k <count ; k++ ){
		System.out.print(num[k] + " ");
	 }	*/
int flag = 0;
for(int i =0; i<num.length; i++){
	if(num[i] == 2){
		System.out.print(num[i]+ " ");
	}
	else{
		flag = 0;
		for(int j = 2; j<num[i] ; j++){
			if(num[i] % j == 0){
			    flag = 1;
				break;
			}			
		}
		if(flag == 0){
			System.out.print(num[i]+ " ");
		}		
	}	
}				
  }
}
