package Same_Array_Pattern;

public class Remove_Duplicates_Same_Array {
	// don not refer this . plz refer to ount_Repeated_Words_Without_HasMap
       public static void main(String [] ar){	
	
    	    String words [] = {"ABCD","Mohit","Mohit", "Mohit","Mohit","Mohit", "Latwal","Latwal","Latwal","Latwal","Infosys","Karnataka","Karnataka"};
    	//   String words [] = {"ABCD", "ABCD","ABCD","ABCD"};
	//        int flag = 0 ;
	//        int counter = 0;
        //    String temp="";
	         for(int i = 0 ; i < words.length; i++){
	        	// temp = words[i];
	        	 for(int j = i+1 ; j< words.length ; j++){
	        	// for(int j= words.length - 1; j>=0 ; j--){
	        		if(words[j] == words[i]){	        			
	        			//flag =1;
	    	        	//words[counter] = words[i];
	    	        	//++counter;
	        			words[j] = "";
	        			//break;
	        		}
	        	  
/*	        		else if(words[j] != words[i]){
	        				flag =2 ;        				        			
	        		}*/
/*	        		else {
	        			words[counter] = words[i];
	        		}*/
	      
	        	 }
	        	// words[counter] = words[i];
/*	        if(flag == 2 ){	        
	        	words[counter] = words[i];
	        	++counter;
	        	flag = 0;
	        	
	        }*/
/*	        if(i == words.length -1){
	        	words[counter] = words[i]; //temp;
	        }*/
	    }
	         	        
	 for(int k = 0; k<words.length ; k++){
	     if(words[k]!= "")
		 System.out.print(words[k] + " ");
 }       
  }
	 }

