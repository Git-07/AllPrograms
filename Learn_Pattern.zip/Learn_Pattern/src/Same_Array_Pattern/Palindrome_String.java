package Same_Array_Pattern;

public class Palindrome_String {

	public static void main(String[] ar){
		
		String word = "reliefpfpfeilr";	// this will be the argument in method	
		int flag = 0;
		int n = word.toCharArray().length;
		for(int i =0 ; i <n/2 ; i++){
			if(word.charAt(i) !=  word.charAt(n-i-1)){
				System.out.println("String is not Palindrome");   // this will be return
				flag = 0;
				break;
			}
			else
			{
				flag = 1;
			}
		}
	   if(flag == 1){
		   System.out.println("String is Palindrome");		   // this will be return
	   }	
	}
}
