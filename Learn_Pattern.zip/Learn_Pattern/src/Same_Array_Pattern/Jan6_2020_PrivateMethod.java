package Same_Array_Pattern;

public class Jan6_2020_PrivateMethod {
	
	private int privateMethod(){
		System.out.println("Private method of Jan6_2020_PrivateMethod");
		return 1;
	}

}
