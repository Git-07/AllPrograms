package Same_Array_Pattern;

public class Garbage_Collector {
	
    int j=12;  
    void add()  
    {  
        j=j+12;  
        System.out.println("J="+j);  
    }  
    public void finalize()  
    {  
        System.out.println(this + " Object is garbage collected");  
    }  
    public static void main(String[] args) {  
        new Garbage_Collector().add();  
        new Garbage_Collector().add();  
        System.gc();  
        
    }  

}
