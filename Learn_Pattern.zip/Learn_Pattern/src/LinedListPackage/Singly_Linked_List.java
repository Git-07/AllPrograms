package LinedListPackage;

// Inserting a String in the integer Singly linked list
 class ListNode {
    
    int data;
    String val;
    ListNode next;
  
    ListNode(int data){
  	
	   this.data = data;

   }
    ListNode(String val){
 	   this.val = val;
 	
    }
	public  void display(ListNode current){
		if(current.val == null){
    	System.out.print(current.data + "-->");
		}
		else if(current.val != null){
			System.out.print(current.val + "-->");
		}
    	
	}
	public  ListNode insertAtPosition(ListNode head, int position, String data){
		ListNode newNode = new ListNode(data);
		ListNode previousNode = head;
		int count = 1;
		while(count < position -1){
			previousNode = previousNode.next;
			count ++;
		}
		ListNode current = previousNode.next;
		newNode.next = current;		
		previousNode.next = newNode;	
		return head;
	}
	
 }
public class Singly_Linked_List {
           
	public static void main(String[] ar){
	
        ListNode head = new ListNode(0);
        ListNode second = new ListNode(8);
        ListNode third = new ListNode(1);
        ListNode fourth = new ListNode(11);
        
        head.next = second;
        second.next = third;
        third.next =  fourth;
        ListNode current = head;
        current.insertAtPosition(head, 3, "Mohit");
        current.insertAtPosition(head, 4, "Latwal");
       // insertAtPosition(current,3,15);
        while(current != null){
        	//display(current);
        	current.display(current);
        	current = current.next;
        }
	    System.out.print("null");
   }
	
	public static void display(ListNode current){
    	System.out.print(current.val + "-->");
    	
	}
	
/*	public static void insertAtPosition(ListNode head, int position,int data){
		ListNode newNode = new ListNode(data);
		ListNode previousNode = head;
		int count = 1;
		while(count < position -1){
			previousNode = previousNode.next;
			count ++;
		}
		ListNode current = previousNode.next;
		newNode.next = current;		
		previousNode.next = newNode;		
	}*/
}

















//private ListNode head;

/*      private static class ListNode {
    
 	private int data;
    private ListNode next;
    
    ListNode(int data){
    	
	   this.data = data;
	   this.next = null;
   }
  }
*/    