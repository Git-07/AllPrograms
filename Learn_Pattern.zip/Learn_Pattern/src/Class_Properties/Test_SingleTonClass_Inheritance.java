package Class_Properties;
import  Class_Properties.Singleton_Class;
public class Test_SingleTonClass_Inheritance{
	
	public static void main(String [] a){
	
		WithoutSingleTon.actualSingleTon.invokeTheSingleTonConstructorMethod1();
	
	}

}
