package Pack2;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Class1 {
	WebDriver driver;
	@BeforeTest		
	/*public  void ieSetup() throws IOException{
		DesiredCapabilities dc = DesiredCapabilities.internetExplorer();
		driver  = new RemoteWebDriver(new URL("http://mohit-PC:4444/wd/hub"),dc);		
	}*/	
	public void chromeSetup() throws Exception  {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\mohit\\Downloads\\Compressed\\chromedriver.exe");	
		DesiredCapabilities dc = DesiredCapabilities.chrome();
		ChromeOptions options  = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.addArguments("start-maximized");
	    //driver = new ChromeDriver(options);
		driver = new ChromeDriver();
	    driver.manage().window().maximize();	  
		dc.setCapability(ChromeOptions.CAPABILITY, options);
//		driver = new RemoteWebDriver(new URL("http://mohit-PC:4444/wd/hub"), dc);
	}
	
	@Test
	public  void failedCheck(){
		driver.get("https://google.com/");
		WebDriverWait wait  = new WebDriverWait(driver,15);
		System.out.println("failed check Method");
		WebElement ele =  wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[name='q']")));
		ele.sendKeys("Remote WebDriver");
		ele.sendKeys(Keys.ENTER);
		WebElement ele1 =  wait.until(ExpectedConditions.presenceOfElementLocated(By.id("hdtb-tl")));
		ele1.click();
	}
	
	@AfterMethod
	
	public void close(){
		driver.quit();
	}
}
