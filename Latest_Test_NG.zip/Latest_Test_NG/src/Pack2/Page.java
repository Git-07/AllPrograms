//Page file

package Pack2;
import java.io.IOException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Pack1.Class2;
public class Page {

public WebElement pageElement(RemoteWebDriver rw){
	WebDriverWait wait = new WebDriverWait(rw,60);
	//WebElement ele =  wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='tsf']/div[2]/div/div[1]/div/div[1]/input")));
	WebElement ele =  wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[name='q']")));
	return ele;
}	
}
