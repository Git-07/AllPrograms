
package Pack1;
import java.awt.List;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Factory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import Pack1.Class2.*;
import Pack2.Page;
public class Class1 {
	//Test file
   Page pg = new Page();
   Class2 cl = new Class2();
   static int test1;
   static int test2;

		@Factory
		public Object[] getTestClasses() {
			Object[] tests = new Object[3];
			for(int i=0; i<3;i++){
			tests[i] = new Class1();
			}
			return tests;
			
		}
	@Parameters( {"instance"} )
	@BeforeTest
	public void auto(int instance){
		if(instance>10){
	    test1 = instance;	
		System.out.println("greater " + instance);
		}
		if(instance<7){
	     test2 = instance;
		System.out.println("less " + instance);
		}
	}	
	@Parameters( {"instance"} )
	@BeforeMethod
	public void setup(int instance) throws Exception{
		cl.ieSetup(instance);
	}
	@Parameters( {"instance"} )
	@AfterMethod
	public void down(int instance) throws Exception{
		cl.driverInstance(instance).close();
	}
	@Parameters( {"instance"} )
	@Test
	public  void standaloneTest(int instance){		
		try{
			
		    //cl.execution(instance);
		    cl.driverInstance(instance).get("https://google.com/");	
			System.out.println(cl.driverInstance(instance).getSessionId());
			pg.pageElement(cl.driverInstance(instance)).sendKeys("Remote Web driver");
			pg.pageElement(cl.driverInstance(instance)).sendKeys(Keys.ENTER);
			Thread.sleep(2000);				
		    test1++;test2++;
			System.out.println(test1);
			System.out.println(test2);  
	//	DesiredCapabilities dc = DesiredCapabilities.chrome();
/*		DesiredCapabilities dc1 = DesiredCapabilities.internetExplorer();
		dc.setPlatform(Platform.WINDOWS);
		dc1.setPlatform(Platform.WINDOWS);
	*/
			

		//System.setProperty("webdriver.ie.driver", "C:\\Users\\mohit\\Downloads\\IEDriverServer.exe");
		//DesiredCapabilities dc1 = DesiredCapabilities.internetExplorer();
		//WebDriver driver2 = new InternetExplorerDriver(dc1);
	//	 driver.manage().window().maximize();
//		ChromeOptions options = new ChromeOptions();
//		options.setExperimentalOption("useAutomationExtension", false);
//		options.addArguments("start-maximized");
		//dc.setCapability(ChromeOptions.CAPABILITY, options);
		//RemoteWebDriver driver;
		//driver = new RemoteWebDriver(new URL ("http://mohit-PC:4444/wd/hub"),dc1);
		//driver.manage().window().maximize();
		//	DesiredCapabilities dc1 = DesiredCapabilities.internetExplorer();
			//RemoteWebDriver driver;		
			//driver = new RemoteWebDriver(new URL ("http://mohit-PC:4444/wd/hub"),dc1);
		//	RemoteWebDriver instance= new RemoteWebDriver(new URL ("http://mohit-PC:4444/wd/hub"),dc1);
			//driver= (RemoteWebDriver) instance;
			
/*			if(instance<7){
			//test1 = testCaseNum; 
			RemoteWebDriver driver1;
			DesiredCapabilities dc1 = DesiredCapabilities.internetExplorer();					
			driver1 = new RemoteWebDriver(new URL ("http://mohit-PC:4444/wd/hub"),dc1);
			driver =driver1;
			System.out.println(test1);			
			test1++;
			}
			if(instance>10){
				//test2 = testCaseNum; 
				RemoteWebDriver driver2;
				DesiredCapabilities dc1 = DesiredCapabilities.internetExplorer();					
				driver2 = new RemoteWebDriver(new URL ("http://mohit-PC:5555/wd/hub"),dc1);
				driver = driver2;
				System.out.println(test2);  
				test2++;
				}*/

		    //System.out.println("hvuhbwugbhwuuvwv " + testCaseNum);
		    
		    
/*		Class2.driver.get("https://google.com/");	
		System.out.println(Class2.driver.getSessionId());
		WebDriverWait wait = new WebDriverWait(Class2.driver,60);
		WebElement ele =  wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='tsf']/div[2]/div/div[1]/div/div[1]/input")));
		ele.sendKeys("Remote Web driver");
		ele.sendKeys(Keys.ENTER);
		Thread.sleep(2000);	*/
/*		driver.close();
		RemoteWebDriver driver2;
		driver2 = new RemoteWebDriver(new URL ("http://mohit-PC:4444/wd/hub"),dc1);
		driver2.manage().window().maximize();
		driver2.get("https://www.google.com/");		
		Thread.sleep(3000);
		WebDriverWait wait1 = new WebDriverWait(driver2,60);
		//List<WebElement> ele2 =    driver2.findElements(By.tagName("input"));	
	     WebElement ele2 =  //driver2.findElement(By.xpath("//*[@id='tsf']/div[2]/div/div[1]/div/div[1]/input")); 
	    		 wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='tsf']/div[2]/div/div[1]/div/div[1]/input")));
		//System.out.println(ele2.getText());
		//ele2.click();		
		ele2.sendKeys("Remote Web driver");
		ele2.sendKeys(Keys.ENTER);
		driver2.close();*/
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
/*	@Parameters( {"instance"} )
	@Test
	public  void method(int instance){
		System.out.println("hvuhbwugbhwuuvwv " + instance);
	}*/
	
}
