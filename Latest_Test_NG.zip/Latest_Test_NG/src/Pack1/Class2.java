package Pack1;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

//action file
import Pack2.Page;
public class Class2 {
	Page pg = new Page();
	RemoteWebDriver driver;
	RemoteWebDriver driver1;
	RemoteWebDriver driver2;
	public void ieSetup(int instance) throws IOException{

		if(instance<7){
		DesiredCapabilities dc1 = DesiredCapabilities.internetExplorer();					
		driver1 = new RemoteWebDriver(new URL ("http://mohit-PC:4444/wd/hub"),dc1);			
		}
		else if(instance>10){
			DesiredCapabilities dc1 = DesiredCapabilities.internetExplorer();					
			driver2 = //new RemoteWebDriver(new URL ("http://mohit-PC:5555/wd/hub"),dc1);
					new RemoteWebDriver(new URL ("http://mohit-PC:4444/wd/hub"),dc1);
			}	
	}	
	public  RemoteWebDriver driverInstance(int instance) throws Exception{
		if(instance<7){							
			driver =driver1;				
			}
		else if(instance>10){							
				driver = driver2;
				}
		
	/*	driver.get("https://google.com/");	
		System.out.println(driver.getSessionId());
		//WebDriverWait wait = new WebDriverWait(driver,60);
		//WebElement ele =  wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='tsf']/div[2]/div/div[1]/div/div[1]/input")));		
		pg.pageElement(driver).sendKeys("Remote Web driver");
		pg.pageElement(driver).sendKeys(Keys.ENTER);
		Thread.sleep(2000);	
		driver.close();*/
		return driver;
	}
	
/*	@Test
	public void Home(){
		System.out.println("home Test cases from Package1 Class");
	}*/
   public int fetchIndex(String Name, List<WebElement> elements){
	   int headerIndex = -1 ;
       for(int i = 0 ; i < elements.size() ; i++){
    	   if(elements.get(i).getText().contentEquals(Name)){
    		   headerIndex = i;
    		   break;
    	   }
       }	   
	   return headerIndex;
   }
   
  public int fetchRowIndex (String Name , List<WebElement> elements){
	   int rowIndex = -1;  
	    for(int i =0 ;i <elements.size() ; i++ ){
	    	//System.out.println("wdkjcbkjwdcjkwbjv " + elements.get(i).getText());
	    		if(elements.get(i).findElement(By.cssSelector("td a")).getText().equals(Name)){
	    			rowIndex = i;
	    			//break;
	    		}
	    	}	    
	   return rowIndex;
    }
 }

