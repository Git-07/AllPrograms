package Pack1;
import Pack1.Class2;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.core.util.WatchManager;
import org.omg.CORBA.portable.Delegate;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Factory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


public class Test_Module1 {
	WebDriver driver;
	//WebDriver driver2;
	@BeforeTest		
	/*public  void ieSetup() throws IOException{
		DesiredCapabilities dc = DesiredCapabilities.internetExplorer();
		driver  = new RemoteWebDriver(new URL("http://mohit-PC:4444/wd/hub"),dc);		
	}*/	
	public void chromeSetup() throws Exception  {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\mohit\\Downloads\\Compressed\\chromedriver.exe");	
		DesiredCapabilities dc = DesiredCapabilities.chrome();
		ChromeOptions options  = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		options.addArguments("start-maximized");
	    //driver = new ChromeDriver(options);
		driver = new ChromeDriver();
	    driver.manage().window().maximize();	  
		dc.setCapability(ChromeOptions.CAPABILITY, options);
		driver.get("https://www.youtube.com/");
		WebDriverWait wait  = new WebDriverWait(driver,60);
		WebElement search = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("search")));
		search.sendKeys("comedy circus kapil sharma best performance");
		search.sendKeys(Keys.ENTER);
		List<WebElement> allVideos = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.id("video-title")));
		allVideos.get(0).click();
//		driver = new RemoteWebDriver(new URL("http://mohit-PC:4444/wd/hub"), dc);
	}
	

	@Test
	public  void failedCheck() throws InterruptedException{
		boolean skipAd = false;
		//driver.get("https://www.youtube.com/");
		
		System.out.println("failed check Method");
		//WebElement ele =  wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[name='q']")));

		//need to select here which video you want to see		
		//clcik on skip ad
		//get the duration of the video.
		//Click on skip ad and get the duration again 
		//match it with the current time
		
		int dura = 1;
		int cur = 0;
       // do{
		Thread.sleep(5000);
		   WebDriverWait wait  = new WebDriverWait(driver,60);
		    WebElement videoContainer = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("html5-video-container")));
		    Actions action = new Actions(driver);		    
		    action.moveToElement(videoContainer).build().perform();
        	WebElement duration = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("ytp-time-duration")));
            WebElement current =   wait.until(ExpectedConditions.presenceOfElementLocated(By.className("ytp-time-current")));
			//dura = Integer.valueOf(duration.getText());
			//cur = Integer.valueOf(current.getText());
            System.out.println("Wejlnwjbwje "+ duration.getText());
            System.out.println("sjkdncjksdncjksnkd "  + current.getText()); 
            action.moveToElement(videoContainer).build().perform();
            wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[title='Full screen (f)'']"))).click();
            WebElement skipad =  wait.until(ExpectedConditions.presenceOfElementLocated(By.className("ytp-ad-skip-button ytp-button")));
            		//y.cssSelector("[title='Full screen (f)']")));
            System.out.println("wlv nwlkncvklwnvw " + skipad.getText());
    		skipad.click();
 /*       try{        	

		
		skipAd = true;
		}catch(Exception e){
		}*/	
		//}while(dura != cur && skipAd == true);

		//driver1.close();
	}
	
/*	@Test	
	public void dynamicWebTable(){
		//WebDriver driver2 =  new ChromeDriver();		
	    System.out.println("dynamicWebTable method");
		driver.get("http://demo.guru99.com/test/web-table-element.php#");
		WebDriverWait wait = new WebDriverWait(driver,10);
		WebElement table = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("dataTable")));
		WebElement headerParent = wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("thead")));
		WebElement bodyParent = wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("tbody")));
		List <WebElement> headers = headerParent.findElements(By.tagName("th"));		
		System.out.println("Elements in list " + headers.size());
				//(wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("th"))));
		List <WebElement> body = bodyParent.findElements(By.tagName("tr"));
		System.out.println("Elements in body list " + body.size());
		//List <WebElement> rowElements = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("tr td")));
		Class2 cl2 = new Class2();
		int companyIndex = cl2.fetchIndex("Company", headers);
		System.out.println("company index " + companyIndex);
		int currentPriceIndex = cl2.fetchIndex("Current Price (Rs)", headers);
		System.out.println("currentPriceIndex is " + currentPriceIndex);
		int rowRequired = cl2.fetchRowIndex("NIIT Technologies", body);
		System.out.println("rowRequired is " + rowRequired);
		String currentPrice = body.get(rowRequired).
		                      findElements(By.tagName("td")).get(currentPriceIndex).getText();
		System.out.println(currentPrice);
		//driver2.close();

	}*/
	@AfterTest
	public void close(){
		driver.close();
		//driver2.close();
	}	
}
