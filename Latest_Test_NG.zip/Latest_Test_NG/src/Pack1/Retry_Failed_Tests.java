package Pack1;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class Retry_Failed_Tests implements IRetryAnalyzer {

	int counter  = 0 ; 
	int retry = 2;
	public boolean  retry(ITestResult result){
		if(counter < retry){
			System.out.println("Retry for failed test");
			counter++;
			return true;
		}
		return false;
	}
}
