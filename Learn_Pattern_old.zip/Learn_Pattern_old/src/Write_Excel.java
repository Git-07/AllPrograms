import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Write_Excel {
	static XSSFRow row;
	static XSSFCell cell;

	public static List<String> getTheExcelData(int sheetIndex, String colName, String path) throws IOException {
		String key = colName;
		List<String> val = new ArrayList<String>();
		int colIndex = 0;
		InputStream file = new FileInputStream(path);
		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet sheet = wb.getSheetAt(sheetIndex);
		Iterator<Row> rows = sheet.rowIterator();
		while (rows.hasNext()) {
			row = (XSSFRow) rows.next();
			if (row.getRowNum() == 0) {
				Iterator<Cell> cells = row.cellIterator();
				while (cells.hasNext()) {
					cell = (XSSFCell) cells.next();
					if (cell.getStringCellValue().equals(colName)) {
						colIndex = (int) cell.getColumnIndex();
						//System.out.println("Column index of the required column " + colIndex);
					}
				}  } else if (row.getRowNum() != 0) {
				Iterator<Cell> cells = row.cellIterator();
				cell = (XSSFCell) cells.next();
				try {
				while (cell.getColumnIndex() != colIndex) {
					cell = (XSSFCell) cells.next();
				}
				switch (cell.getCellType()) {
				case Cell.CELL_TYPE_NUMERIC:
				
					System.out.println(val);
					break;
				case Cell.CELL_TYPE_STRING:
					val.add(cell.getStringCellValue());
					break;
				case Cell.CELL_TYPE_BLANK :					
					val.add(" ");
				}
				
			}catch(Exception e){
				val.add(" ");
				//System.out.println(val);
				//	System.out.println(e);
				}
				}}
	
		return val;
	}

	public static void setColorToExcel(int sheetIndex, int rowNum, String path) throws IOException {

		InputStream file = new FileInputStream(path);
		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet sheet = wb.getSheetAt(sheetIndex);
		Iterator<Row> rows = sheet.rowIterator();
		while (rows.hasNext()) {
			CellStyle style = wb.createCellStyle();
			row = (XSSFRow) rows.next();
			if (row.getRowNum() == rowNum) {
				style.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
				style.setFillPattern(FillPatternType.LEAST_DOTS);
				Iterator<Cell> cells = row.cellIterator();
				cell = (XSSFCell) cells.next();
				cell.setCellStyle(style);
				break;
			}
		}
		FileOutputStream fileOut = new FileOutputStream(path);
		wb.write(fileOut);
		fileOut.close();
	}	
    		
	public static void writeToExcelAtAnIndex(int sheetIndex, String colName,int columnIndex, List<String> str, String path) throws IOException {

		int i = 0;
		XSSFCell cell;
		XSSFSheet sheet;
		XSSFWorkbook wb;
		XSSFRow row ;		
			FileInputStream fileIn = new FileInputStream(path);
			wb = new XSSFWorkbook(fileIn);
			sheet = wb.getSheetAt(sheetIndex);		
		row = sheet.createRow(i++);		
		for (int r = 0; r < str.size(); r++) {
			row = sheet.createRow(i++);
			row.createCell(columnIndex).setCellValue(str.get(r));
			FileOutputStream fileOut = new FileOutputStream(path);
			wb.write(fileOut);
			fileOut.close();
		}
	}

	public static void writeToExcel(int sheetIndex, String sheetName, ArrayList<String> list, List<ArrayList<String>> datas, String path) throws IOException {

		int i = 0;
		XSSFCell cell;
		XSSFSheet sheet;
		XSSFWorkbook wb;
		XSSFRow row ;
		FileInputStream fileIn = new FileInputStream(path);
		if (sheetIndex >= 1) {
			//FileInputStream fileIn = new FileInputStream(path);
			wb = new XSSFWorkbook(fileIn);
			sheet = wb.getSheetAt(sheetIndex);
		} else {
			wb = new XSSFWorkbook(fileIn);
			sheet = wb.createSheet(sheetName);
			
		}
		row = sheet.createRow(i++);
		for(int j = 0 ; j< list.size() ;j++){
		row.createCell(j).setCellValue(list.get(j));				
		}		

		for (int r = 0; r <datas.get(0).size(); r++) {			
			row = sheet.createRow(i++);
			for(int k=0 ; k<list.size() ;k++){
			row.createCell(k).setCellValue(datas.get(k).get(r));
		}		
	}
		FileOutputStream fileOut = new FileOutputStream(path);
		 wb.write(fileOut);			
		fileOut.close();
		wb = new XSSFWorkbook(new FileInputStream(path));
}

	public static void main(String[] ar) throws IOException {
		XSSFCell cell;
		XSSFSheet sheet;
		XSSFWorkbook wb;
		XSSFRow row ;
		FileInputStream fileIn = new FileInputStream("C:\\Users\\mohit\\Desktop\\Control_Numbers.xlsx");
			wb = new XSSFWorkbook(fileIn);
		  sheet = wb.getSheetAt(0);
   Map<String , String> map = new HashMap<String , String>();
		for(int i =0 ; i< 3; i++){
			ArrayList<String> arr1 = new ArrayList<String>();
			arr1.add("ABCD"+ i);
			arr1.add("EFGH" + i);
			ArrayList<String> arr2 = new ArrayList<String>();
			arr2.add("21211221" + i);
			arr2.add("3223155" + i);
 
  for(int l = 0 ; l< arr1.size() ; l++){
  map.put(arr1.get(l), arr2.get(l));
  }
  arr1.clear();
  arr2.clear();
  }
  Set<String>  keyset = map.keySet();  
  int rows = 0;
  for(String key : keyset){
	  row = sheet.createRow(rows++);
	  row.createCell(0).setCellValue(map.get(key));
	  row.createCell(1).setCellValue(key);
  }
		FileOutputStream fileOut = new FileOutputStream("C:\\Users\\mohit\\Desktop\\Control_Numbers.xlsx");
		 wb.write(fileOut);			
		 fileOut.close();
		 fileIn.close();
		  //int rows = sheet.getPhysicalNumberOfRows();	
		  
	  
	  //String value = map.get(key);
	  	  
  }

		//}

/*			String data1 = "Mohit";
			String data2  = "Latwal";
			writeExcel(data1,data2,getPhysicalRows());
			writeExcel(data1,data2,getPhysicalRows());
		}*/
	//}
			
/*		List<String> cntrl = new ArrayList<String>();		
		cntrl.add("123456");
		cntrl.add("234567");
		cntrl.add("345678");			
		List<ArrayList<String>> datas = new ArrayList<ArrayList<String>>();			
		ArrayList<String> list1 = new ArrayList<String>();
		ArrayList<String> list2 = new ArrayList<String>();
		ArrayList<String> list3 = new ArrayList<String>();
		
		list3.add("Fields desc");list3.add("Field");
		List<String> target = getTheExcelData(0, "Fields desc", "C:/Users/mohit/Desktop/Controls/Refer.xlsx");
		for(int l =0 ;l<cntrl.size() ;l++){			
		List<String> source = getTheExcelData(0, "Fields desc", "C:/Users/mohit/Desktop/Controls/" + cntrl.get(l) +".xlsx");				
		int flag = 0;
		
		for(int k =0; k< 2 ; k++){
		for (int i = 0; i < source.size(); i++) {
					
			for (int j = 0; j < target.size(); j++) {
				if (source.get(i).equals(target.get(j))) {					
					setColorToExcel(0, i + 1, "C:/Users/mohit/Desktop/Controls/" + cntrl.get(l) +".xlsx");
					flag = 1;					
					break;
				} else {
					flag = 2;
				}
			}
			if (flag == 2) {
				list1.add(getTheExcelData(0, "Fields desc", "C:/Users/mohit/Desktop/Controls/" + cntrl.get(l) +".xlsx").get(i));
				list2.add(getTheExcelData(0, "Field", "C:/Users/mohit/Desktop/Controls/" + cntrl.get(l) +".xlsx").get(i));				
				flag = 0;				
			}
		}
	    datas.add(list1);
	    datas.add(list2);
		writeToExcel(0,"Pending_Analysis",list3, datas,"C:/Users/mohit/Desktop/Controls/" + cntrl.get(l) +".xlsx");
		System.out.println(1);
		
		list1.clear();list2.clear();datas.clear();source.clear();
		 }		
	}*/

		public static void writeExcel(String data1, String data2,int rows) throws IOException{
		

			//int i = 0;
			XSSFCell cell;
			XSSFSheet sheet;
			XSSFWorkbook wb;
			XSSFRow row ;
			FileInputStream fileIn = new FileInputStream("C:\\Users\\mohit\\Desktop\\Control_Numbers.xlsx");
				wb = new XSSFWorkbook(fileIn);
			  sheet = wb.getSheetAt(0);
			  //int rows = sheet.getPhysicalNumberOfRows();	
			  System.out.println("djhbwdhjhdjhbdshvc " + rows);
				row = sheet.createRow(rows++);				
				row.createCell(0).setCellValue(data1);
				row = sheet.createRow(rows++);
				row.createCell(0).setCellValue(data2);
							
			FileOutputStream fileOut = new FileOutputStream("C:\\Users\\mohit\\Desktop\\Control_Numbers.xlsx");
			 wb.write(fileOut);			
			 fileOut.close();
			 fileIn.close();
		//	wb = new XSSFWorkbook(new FileInputStream("C:\\Users\\mohit\\Desktop\\Control_Numbers.xlsx"));
	
	}
		
		public static int getPhysicalRows() throws IOException{


  
			
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
			XSSFCell cell;
			XSSFSheet sheet;
			XSSFWorkbook wb;
			XSSFRow row ;
			FileInputStream fileIn = new FileInputStream("C:\\Users\\mohit\\Desktop\\Control_Numbers.xlsx");
				wb = new XSSFWorkbook(fileIn);
			  sheet = wb.getSheetAt(0);
			return  sheet.getPhysicalNumberOfRows();
	}
}