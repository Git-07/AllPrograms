import java.util.*;
import java.io.FileInputStream;
import java.io.InputStream;
import org.apache.poi.xssf.usermodel.*; // Row and Cell will be there
import org.apache.poi.ss.usermodel.*;
public class Excel_Read {
	static int number;
	static boolean bool;
	static String textVal="";
	static int colIndex;
	static int flagIndex;
	static InputStream file;
	static XSSFWorkbook wb;
	static XSSFSheet sheet;
	static XSSFRow row;
	static XSSFCell cell;
	static String data  = "";
	static int flag = 0;
	
	public static void setTheNumericValue(int num){
		number = num;
	}
	public static String getTheNumericValue(){
		
		return String.valueOf(number);
	}
	
	public static void setTheStringValue(String text){
		
		textVal = text;
	}
	public static String getTheStringValue(){
		
		return textVal;
	}
	public static void setTheBooleanData(boolean booleanValue){
		bool = booleanValue;
	}
	public static String getTheBooleanValue(){
		return String.valueOf(bool);
	}
	
	public static void main(String[] a) throws Exception{
		
		getTheValueFromExcel("TC_04",1,"Company");
		System.out.println(data);
		
	}

	@SuppressWarnings("deprecation")
	public static void getTheValueFromExcel(String testCaseId,int sheetIndex, String colName) throws Exception{
					
			file = new FileInputStream("C:/Users/mohit/Desktop/Test_Data.xlsx");
			wb = new XSSFWorkbook(file);
			sheet = wb.getSheetAt(sheetIndex);					
			int noOfColumns = sheet.getRow(0).getLastCellNum();
			System.out.println("number of columns " + noOfColumns);
			Iterator<Row> rows = sheet.rowIterator();			
		    while(rows.hasNext()){		    		   
		   		row = (XSSFRow) rows.next();
		   		if(row.getRowNum() == 0 ){
			    Iterator<Cell> cells = row.cellIterator();			    
			    while(cells.hasNext()){		
			    	cell = (XSSFCell) cells.next();
		    	     if(cell.getStringCellValue().equals(colName)){
		    	    	 colIndex = (int)cell.getColumnIndex();
		    	    	 System.out.println("Column index of the required column "+ colIndex);		    	    
		    	    	
		    	       } 	 		 	    	     		    	     
		    	    }
		   	}
		   	else if(row.getRowNum() !=0){		   				   	
		   	   Iterator<Cell> cells = row.cellIterator();
		   	    cell = (XSSFCell) cells.next();  			                      		    	
                      
	   		if(cell.getStringCellValue().contentEquals(testCaseId)){
	   			flag = 1;
	   			try{
		     			
		     			while(cell.getColumnIndex() != colIndex){
		    				cell = (XSSFCell) cells.next();
		     			}
		    		switch (cell.getCellType()){		    	
		    		case Cell.CELL_TYPE_NUMERIC :
		    			setTheNumericValue((int) cell.getNumericCellValue());
		    			data = getTheNumericValue();		    			
		    		  break;
		    		case Cell.CELL_TYPE_STRING :
		    			setTheStringValue(cell.getStringCellValue());
		    			data = getTheStringValue();		    		
		    			break;
		    		case Cell.CELL_TYPE_BOOLEAN :
		    			setTheBooleanData(cell.getBooleanCellValue());
		    			data = getTheBooleanValue();		   
    			
		    		}
		    			    	
		   	}
	   			catch(Exception e){
	   				data = "null";		
	   				}
		    	
	   		}

		}
	   		
     }					
			wb.close();
			if(flag == 0)
				
	   		{
	   			System.out.println("Please search with the coorect Test Case Id");
	   			data = "null";
	   		}
	}
	
  
}