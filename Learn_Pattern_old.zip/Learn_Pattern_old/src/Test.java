import java.util.*;
import org.apache.logging.log4j.*;

public class Test {
	
	private static Logger log = LogManager.getLogger(Test.class.getName());

	 static public void main(String[] ar){		 
				
		System.out.println("in default package");
		log.debug("element needs to be clicked");
		log.info("element is clicked");
		log.error("element is not clicked");
		log.fatal("element is fatal");
	}
}
