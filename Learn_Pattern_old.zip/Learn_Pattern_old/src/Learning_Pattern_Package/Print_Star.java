package Learning_Pattern_Package;
import java.util.*;
public class Print_Star {
public static void main(String[] a){
    int c = 0;
	int count ;
    int i;
	Scanner scan =  new Scanner(System.in);	
	System.out.println("Entyer the number");
	int number  = scan.nextInt();
	count = number;
	int counter = number;
    while(count>=1){
	for(i = number ; i>=1; i--){	
		  if(i >=counter){
			System.out.print(i);			
			c++;		 
		  }
    }	
	for(; c<number;c++){		
	System.out.print("*");
	}
	c= 0;	
	System.out.println();
	counter--;
	count--;
  }
}
}
