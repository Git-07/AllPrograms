package Learning_Pattern_Package;

public interface TestInterface {
	
	int a =1;
	String s = "abcd";
	public  void unimplmentedMethod();

}
