package Learning_Pattern_Package;

public class Count_Of_Occurence {

	public static void main(String[] tr){
		String str = "MoeeeeeeeeeeeeeeeeeeeeeeeMhit Mohit lives in Mysore";
//		String[] strarr = str.split("//+");
		int counter = 1;
		int index = 0;
		char[] ch = str.toCharArray();
		int[] arrCount = new int[ch.length];
		for(int i=0; i<ch.length; i++){
			for(int j=i+1; j<ch.length; j++){
			if(ch[j] == ch[i] && ch[j] !=' '){
				arrCount[i] = ++counter;
			    ch[j] =' ';
			}
			}
			if(counter == 1){
				arrCount[i] = counter;	
			}
			System.out.println(ch[i] + " count: " + counter);
			counter = 1;
		}		

	int l = 0;
	for(int k=  l+1 ;k< arrCount.length ; k++){
		if(arrCount[l] > arrCount[k] && arrCount[l] > index){			
			index = arrCount[l];
		//	index = l;
		}
		else if(arrCount[l]  < arrCount[k] && arrCount[k] >index){
			index = arrCount[k];
		//	index = k;
		}		
		System.out.println(index);
	}
	int ind =0;
	for(int j = 0 ; j< arrCount.length; j++){
		if(arrCount[j] == index){
			ind = j;
			break;
		}
	}
	System.out.println(ch[ind]);
}
}