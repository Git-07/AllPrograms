package Learning_Pattern_Package;
import java.util.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
abstract class Vehicle{
	int speed = 100;
    
	
	
	/*Vehicle(){
		
		System.out.println("Abstarct class constructor");
	}*/
	void run(){
	    System.setProperty("webdriver.ie.driver", "D:\\software\\IEDriverServer.exe");
	    WebDriver driver = new InternetExplorerDriver();
		System.out.println("Internet Explorere launch");
   }
}
class Audi extends Vehicle	{
	int speed = 200;
	
	void run(){
		System.setProperty("webdriver.chrome.driver", "D:\\software\\chromedriver_win32 (2)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		System.out.println("Chrome Launch");
		
	}
	
	 static public void main(String[] ar){		 
		Vehicle v = new Audi();
		v.run();
		/*v.run();
		System.out.println(v.speed);
		System.out.println("in Learning pattern package");*/
	}
  }


