package Learning_Pattern_Package;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Pattern_1 {
	
	public static void main(String[] args){
			System.setProperty("webdriver.chrome.driver","D:\\software\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://google.com");
		
		for(int i =3 ; i<=7 ; i++){
			for(int j = 3 ; j<=i ; j++){
			System.out.print(i);
		}
		
			System.out.println();
	}
		for(int k =7 ; k>=3 ;k--){
			for(int l = k; l>=3 ; l--){
				System.out.print(k);
		}
			System.out.println();
		}
	}
}
