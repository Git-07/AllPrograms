package Learning_Pattern_Package;
import java.util.*;
public class Print_Star_Pattern {
	
	public static void main(String[] ar){
		Scanner scan = new Scanner(System.in);
		
		int row = scan.nextInt();
		
		for(int r =1; r<=row ;r++){
			int count = r;
			for(int i =1; i<= row*2 - 2*count ;i++){
				System.out.print(" ");
			}
			if(count == 1){
				System.out.print("X");
			}
			else{		
	   for(int c = 1; c<=count; c++){
		   System.out.print("X");
		   System.out.print(" ");		   
	   }		
	   for(int k = count-1; k>=1;k-- ){
		   System.out.print("X");
		   System.out.print(" ");
	   }
		}
		System.out.println();
	}
	}
}
