	
	import java.util.*;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.InputStream;
	import org.apache.poi.xssf.usermodel.*; // Row and Cell will be there
	import org.apache.poi.ss.usermodel.*;
    public class Excel_Read_Redefined {

	    static XSSFWorkbook wb;
	    static XSSFSheet  sheet;
		static int number;
		static String textVal="";
		static int colIndex;
		static int flagIndex;
		static List<String> errors  = new ArrayList<String>();
		static XSSFRow row ;
		static XSSFCell cell;
		static Iterator<Cell> cells;
		
		public static void setTheNumericValue(int num){
			number = num;
		}
		public static String getTheNumericValue(){
			
			return String.valueOf(number);
		}
		
		public static void setTheStringValue(String text){
			
			textVal = text;
		}
		public static String getTheStringValue(){
			
			return textVal;
		}
		
		public static void main(String[] a) throws Exception{
			
			getTheValueFromExcel(1,"TcFlag","LOBS");
			System.out.println(errors);
			for(String e : errors){
			  System.out.println(e);	
			}
		}
		public static void cellValueReader(int flag,String flagName, String colName) throws Exception{
			if((int) cell.getNumericCellValue() == flag && (int) cell.getColumnIndex() == flagIndex){
     			
	     		//	System.out.println("ljvnjkvbjksvjsk " + cell.getColumnIndex());
	     		//	System.out.println(cell.getColumnIndex());
	     			while(cell.getColumnIndex() != colIndex){
	    				cell = (XSSFCell) cells.next();
	     			}

	    		if(cell.getColumnIndex() == colIndex){	    			
	    		//	System.out.println("skjbvsvbvbhksfvb");
	    		switch (cell.getCellType()){
	    		case Cell.CELL_TYPE_NUMERIC :
	    			setTheNumericValue((int) cell.getNumericCellValue());
	    			errors.add(getTheNumericValue());
	    		  break;
	    		case Cell.CELL_TYPE_STRING :
	    			setTheStringValue(cell.getStringCellValue());
	    			errors.add(getTheStringValue());
	    			break;
	    		case  Cell.CELL_TYPE_BLANK :
	    			
	    		}		    	
	   	     }
			}
		}

		@SuppressWarnings("deprecation")
		public static void getTheValueFromExcel(int flag,String flagName, String colName) throws Exception{
			
				
				InputStream file = new FileInputStream("C:/Users/mohit/Desktop/Test_Data.xlsx");
				 wb = new XSSFWorkbook(file);
				sheet = wb.getSheetAt(0);
				int noOfColumns = sheet.getRow(0).getLastCellNum();
				System.out.println("number of columns " + noOfColumns);
				Iterator<Row> rows = sheet.rowIterator();			
			   // rows.next();
				int m = 0;
			    while(rows.hasNext()){
			    try{
			    row = (XSSFRow) rows.next();
			    cells = row.cellIterator();
			    while(cells.hasNext()){		 
			   	if(row.getRowNum() == 0 && m==0){	   		
			    		while( m < 2){
			    		 cell = (XSSFCell) cells.next();
			    	  //   System.out.println("sdhvbshvjhvhs "+ colIndex);
			    	     if(cell.getStringCellValue().equals(colName)){
			    	    	 colIndex = (int)cell.getColumnIndex();
			    	    	 System.out.println("Column index of the required column "+ colIndex);
			    	    	 m++;
			    	    	
			    	     } 	 		 
			    	     if(cell.getStringCellValue().trim().equals(flagName.trim())){
			    	    	 flagIndex = (int)cell.getColumnIndex();
			    	    //	 System.out.println("llllllllllll "+ flagIndex);		    	    
			    	    	 m++;
			    	    	
			    	      }		    	     		    	     
			    	     }                     
			    	} 		   	  
			   	  if(colIndex <noOfColumns-1){
			   	  cell = (XSSFCell) cells.next();    				                      
			    		if(row.getRowNum() !=0 ){	
			    			Excel_Read_Redefined.cellValueReader(flag, flagName, colName);
		   		
			    	   } 
			   		}
			    	  
			   	  else{ 
			    		if(row.getRowNum() !=0 ){	
			    			cell = (XSSFCell) cells.next();
			    			Excel_Read_Redefined.cellValueReader(flag, flagName, colName);
			    		}
			   	  } 
			   }
			    	
			    	wb.close();
			    
		}
			catch(Exception e){
				//System.out.println(e);
				errors.add("null");		
			}
		
			  }
	 }
}


